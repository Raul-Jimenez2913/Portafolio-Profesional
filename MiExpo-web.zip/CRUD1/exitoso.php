<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8)>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie-edge">
	<title>Registro</title>
	<link rel="shortcut icon" href="/TC2005B_403_1/CRUD1/images/l2.jpg" type="image/x-icon">
	<link rel="stylesheet" href="/TC2005B_403_1/CRUD1/css/estilos20.css">
</head>

<body>
		
	<header>
		<table class="barra">
			<tr>
				<td> <img src="/TC2005B_403_1/CRUD1/images/expo1.jpg" alt="" class="logo"> </td>
			</tr>
		</table>
		
	</header>
		
		
		
	<section>
		<div class="proyectos" align="center">
			<h1>Resgistro exitoso</h1>
		</div>
		
		<div class="registrar" align="center">
			<a href="/TC2005B_403_1/CRUD1/index.php"><input type="button" value="Volver a Inicio" class="guardar"></a>
		</div>	
		
	</section>
	
</body>
	
</html>
