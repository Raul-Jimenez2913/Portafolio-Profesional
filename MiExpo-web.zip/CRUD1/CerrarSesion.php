<?php
session_start();
session_unset();
session_regenerate_id(true);
header("Location: /TC2005B_403_1/CRUD1/index.php");
exit();
?>
