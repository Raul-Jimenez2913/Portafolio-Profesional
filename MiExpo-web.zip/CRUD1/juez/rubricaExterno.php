<?php

session_start(); // Inicia la sesión

// Asigna el valor de la variable de sesión a la variable matricula
$ide = $_SESSION['id'];


require 'database.php';
$id = null;
$idDoc=4;

$preg1Error = null;
$preg2Error = null;
$preg3Error = null;
$preg4Error = null;

if (!empty($_GET['id'])){
    $id = $_REQUEST['id'];
}
if ( $id==null ) {
 header("Location: index.php");
}else{
  $pdo = Database::connect();
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sqln='SELECT nombre FROM MDP_proyecto WHERE id='.$id;
  $q=$pdo->prepare($sqln);
  $q->execute();
  $nom=$q->fetch(PDO::FETCH_ASSOC);
  $nombre=$nom['nombre'];
  Database::disconnect();
}

if (!empty($_POST)) {
        $preg1 = $_POST['pregunta1'];
        $preg2 = $_POST['pregunta2'];
        $preg3 = $_POST['pregunta3'];
        $preg4 = $_POST['pregunta4'];
        $com = $_POST['comentario'];


        $id_juez = 1;
        $valid = true;

		echo $cal;
		if (empty($preg1)) {
			$preg1Error = 'Porfavor seleccione un campo';
			$valid = false;
		}
		if (empty($preg2)) {
			$preg2Error = 'Porfavor seleccione un campo';
			$valid = false;
		}
		
		if (empty($preg3)) {
			$preg3Error = 'Porfavor seleccione un campo';
			$valid = false;
		}
		
		if (empty($preg4)) {
			$preg4Error = 'Porfavor seleccione un campo';
			$valid = false;
		}
		
		if (empty($com)) {
			$comError = 'Escriba un comentario';
			$valid = false;
		}


        if ($valid) {
			$suma = $preg1 + $preg2 + $preg3 + $preg4 ;
            $pdo = Database::connect();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "UPDATE MDP_jurado_proyecto SET calificacion = ?, comentario = ? WHERE id_proyecto = ? AND id_jurado = ?";
            $q = $pdo->prepare($sql);
            $q->execute(array($suma, $com, $id, $ide));
            Database::disconnect();

            header("Location: index.php");
            exit();
        }
    }

?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8)>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie-edge">
	<title>Rubrica</title>
	<link rel="shortcut icon" href="/TC2005B_403_1/CRUD1/images/l2.jpg" type="image/x-icon">
	<link rel="stylesheet" href="/TC2005B_403_1/CRUD1/css/estilos31.css">
	<script src="js/script1.js"></script>
</head>
<body>

	<header>
	<table class="barra">
			<tr>
				<td> <img src="/TC2005B_403_1/CRUD1/images/expo1.jpg" alt="" class="logo"> </td>
				<td class="Inicio">
					<ul class="menu">
						<li><a href="index.php">Inicio</a></li>
					</ul>
				</td>
				<td>
					<ul class="actual">
						<li><a href="mapaExterno.php">Proyectos</a></li>
					</ul>
				</td>
			</tr>
	</table>
	</header>
	
	<div class="rectangulo">
		<div class="rectanguloTitulo">
			<?php echo $nombre;?> 
		</div>
		
	<form class="form-horizontal" action="rubricaExterno.php?id=<?php echo $id; ?>" method="POST" enctype="multipart/form-data">
		<table class="rubrica">
			<tr num="1">
				<th colspan="5"> Rúbrica </th>
			<tr>
				<th>Aspecto por evaluar</th>
				<th>Insuficiente</th>
				<th>Deficiente</th>
				<th>Suficiente</th>
				<th>Sobresaliente</th>
			
			</tr>
			<tr>
			<div class="control-group <?php echo !empty($preg1Error)?'error':'';?>">
			<td><label class="control-label">Calidad </label></td>
			<div class="controls">
				<td><input type="radio" name="pregunta1" value="0.25" <?php echo ($preg1 == 0.25)?'checked':'';?>> </input></td>
				<td><input type="radio" name="pregunta1" value="0.50" <?php echo ($preg1 == 0.50)?'checked':'';?>> </input></td>
				<td><input type="radio" name="pregunta1" value="0.75" <?php echo ($preg1 == 0.75)?'checked':'';?>> </input></td>
				<td><input type="radio" name="pregunta1" value="1" <?php echo ($preg1 == 1)?'checked':'';?>> </input></td>
				<?php if(!empty($preg1Error)):?>
           			 <span class="help-inline"><?php echo $preg1error;?></span>
        			  <?php endif;?>
			</div>
			</tr>
			
			<tr>
			<div class="control-group <?php echo !empty($preg2Error)?'error':'';?>">
			<td><label class="control-label">Originalidad </label></td>
			<div class="controls">
				<td><input name="pregunta2" type="radio" value="0.25" <?php echo ($preg2 == "0.25")?'checked':'';?>> </input></td>
				<td><input name="pregunta2" type="radio" value="0.50"<?php echo ($preg2 == "0.50")?'checked':'';?>> </input></td>
				<td><input name="pregunta2" type="radio" value="0.75"<?php echo ($preg2 == "0.75")?'checked':'';?>> </input></td>
				<td><input name="pregunta2" type="radio" value="1"<?php echo ($preg2 == "1")?'checked':'';?>> </input></td>
				<?php if (($preg2Error != null)) ?>
						      		<span class="help-inline"><?php echo $preg2Error;?></span>
			</div>
			</div>
			
			</tr>
			
			<tr>
				<div class="control-group <?php echo !empty($preg3Error)?'error':'';?>">
			<td><label class="control-label">Complejidad </label></td>
			<div class="controls">
				<td><input name="pregunta3" type="radio" value="0.25" <?php echo ($preg3 == "0.25")?'checked':'';?>> </input></td>
				<td><input name="pregunta3" type="radio" value="0.50"<?php echo ($preg3 == "0.50")?'checked':'';?>> </input></td>
				<td><input name="pregunta3" type="radio" value="0.75"<?php echo ($preg3 == "0.75")?'checked':'';?>> </input></td>
				<td><input name="pregunta3" type="radio" value="1"<?php echo ($preg3 == "1")?'checked':'';?>> </input></td>
				<?php if (($preg3Error != null)) ?>
						      		<span class="help-inline"><?php echo $preg3Error;?></span>
			</div>
			</div>
			</tr>
			
			<tr>
				<div class="control-group <?php echo !empty($preg4Error)?'error':'';?>">
			<td><label class="control-label">Creatividad </label></td>
			<div class="controls">
				<td><input name="pregunta4" type="radio" value="0.25" <?php echo ($preg4 == "0.25")?'checked':'';?>> </input></td>
				<td><input name="pregunta4" type="radio" value="0.50"<?php echo ($preg4 == "0.50")?'checked':'';?>> </input></td>
				<td><input name="pregunta4" type="radio" value="0.75"<?php echo ($preg4 == "0.75")?'checked':'';?>> </input></td>
				<td><input name="pregunta4" type="radio" value="1"<?php echo ($preg4 == "1")?'checked':'';?>> </input></td>
				<?php if (($preg4Error != null)) ?>
						      		<span class="help-inline"><?php echo $preg4Error;?></span>
			</div>
			</div>
			</tr>
			
		</table>
	
		<div>
			<h3 class="comenTexto">Comentarios</h3>
			<div class="control-group <?php echo !empty($comError)?'error':'';?>">
			<textarea name="comentario" class="comentario" value="<?php echo !empty($com)?$com:'';?>"></textarea>
			<?php if (($comError != null)) ?>
		<span class="help-inline"><?php echo $comError;?></span>
			</div>
		</div>
		
		<td align="right"> <a href=<?php echo '"infoProJurado.php?id='.$id.'"'; ?>> <input type="button" value="Volver" class="guardar" style="margin-bottom: 20px;"> </a> </td>
		
		<div class="form-actions">
<td><button type="submit" class="guardar1">Calificar</button></td>
		</div>
		
	</div>
	</form>	
		

</body>
</html>
