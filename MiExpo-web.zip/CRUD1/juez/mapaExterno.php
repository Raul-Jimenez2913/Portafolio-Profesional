<?php

session_start(); // Inicia la sesión

// Asigna el valor de la variable de sesión a la variable matricula
$ide = $_SESSION['id'];

        include 'database.php';
        $pdo = Database::connect();
        $sql = 'SELECT MDP_extras.* FROM MDP_extras WHERE id=1';
        $i = 0;

        Database::disconnect();
    ?>

<?php
		$pdo = Database::connect();
		$query = 'SELECT mapa AS mapa FROM MDP_extras';
		foreach ($pdo->query($query) as $row) {
		if ($row['id']==$prof)
		"<option selected value='" . $row['id'] . "'>" . $row['mapa'] . "</option>";
		 else
		"<option value='" . $row['id'] . "'>" . $row['mapa'] . "</option>";
		
		$frase = $row['mapa'];
		$subcadena = substr($frase, 32, 33); 
		}
	Database::disconnect();
   ?>
   
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8)>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie-edge">
	<title>Mapa</title>
	<link rel="shortcut icon" href="/TC2005B_403_1/CRUD1/images/l2.jpg" type="image/x-icon">
	<link rel="stylesheet" href="/TC2005B_403_1/CRUD1/css/estilos29.css">
</head>
<body>
	<table class="barra">
		<tr>
			<td class = "Inicio"> <img src="/TC2005B_403_1/CRUD1/images/expo1.jpg" alt="" class="logo"> </td>
			<td class="Inicio">
				<ul class="menu">
					<li><a href="index.php">Inicio</a></li>
				</ul>
			</td>
			<td class = "Inicio">
				<ul class="actual">
					<li><a href="mapaExterno.php">Proyectos</a></li>
				</ul>
			</td>
			<td class = "Inicio">
			</td>
		</tr>
	</table>
	
	<div class="imagenContenedor">
		<img src="/TC2005B_403_1/CRUD1/images/brazo.jpg" alt="" class = "imagenFondo">
		<div class="segmento">
			<img src=<?php echo "https://drive.google.com/uc?export=view&id=".$subcadena;?> alt="" class="mapa">
		</div>
	</div>
	<div class="botones">
		<a href=<?php echo '"proyectoJuez.php?id='.$ide.'"'; ?>> <button class="boton-indicador1">Proyectos a evaluar</button> </a>
		<a href="mapaExterno.php"> <button class="boton-indicador">Mapa</button> </a>
	</div>


</body>
</html>
