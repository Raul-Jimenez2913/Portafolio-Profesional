<?php


	require 'database.php';

		$nombError = null;
		$apeError   = null;
		$corrError   = null;
		$conError   = null;
		$proError = null;


	if ( !empty($_POST)) {

		$nomb = $_POST['nomb'];
		$ape   = $_POST['ape'];
		$corr   = $_POST['corr'];
		$con   = $_POST['con'];
		$pro = $_POST['pro'];



		// validate input
		$valid = true;

		if (empty($nomb)) {
			$nombError = 'Porfavor escriba su nombre';
			$valid = false;
		}
		if (empty($ape)) {
			$apeError = 'Porfavor escriba sus apellidos';
			$valid = false;
		}
		if (empty($corr)) {
			$corrError = 'Porfavor ingrese su correo institucional';
			$valid = false;
		}
		if (empty($con)) {
			$conError = 'Porfavor ingrese una contraseña';
			$valid = false;
		}
		if (empty($pro)) {
			$proError = 'Porfavor ingrese su Institución';
			$valid = false;
		}
		
		
		// insert data
		if ($valid) {
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "INSERT INTO MDP_jurado (id,nombre,apellidos,correo,password,procedencia) values(null, ?, ?, ?, ?, ?)";
			$q = $pdo->prepare($sql);
			$q->execute(array($nomb,$ape,$corr,$con,$pro));
			Database::disconnect();
			header("Location: /TC2005B_403_1/CRUD1/exitoso.php");
			Database::disconnect();

		}
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>RegistroExterno </title>
		<link rel="shortcut icon" href="/TC2005B_403_1/CRUD1/images/l2.jpg" type="image/x-icon">
		<link rel="stylesheet" type"text/css" href="/TC2005B_403_1/CRUD1/css/estilos9.css">
	</head>
	
	<body>
		
		<header>
		<table class="barra">
			<tr>
				<td> <img src="/TC2005B_403_1/CRUD1/images/expo1.jpg" alt="" class="logo"> </td>
				<td class="Inicio">
					<ul class="menu">
						<li><a href="index.php">Inicio</a></li>
					</ul>
				</td>
			</tr>
		</table>
		
			<section class="textos-header">
				<h1> Registro Externo</h1>
			</section>
			<div class="wave" style="height: 150px; overflow: hidden;" ><svg viewBox="0 0 500 150" preserveAspectRatio="none" style="height: 100%; width: 100%;"><path d="M0.00,49.98 C282.44,51.81 294.86,50.83 500.00,49.98 L500.00,150.00 L0.00,150.00 Z" style="stroke: none; fill: #fff;"></path></svg></div>
		</header>

	<form class="form-horizontal" action="RegistroJuez.php" method="POST">
		<div class="contenedor">
			<table class="tabla">
				<tr>
					<td>
						<div class="control-group <?php echo !empty($nombError)?'error':'';?>">
						<label class="control-label">Nombre:</label>
					    <div class="controls">
					    <td>
					      	<input name="nomb" type="text"  placeholder="Nombre" value="<?php echo !empty($nomb)?$nomb:'';?>">
					      	<?php if (($nombError != null)) ?>
					      		<span class="help-inline"><?php echo $nombError;?></span>
					     </td>
					    </div>
						</div>
					</td>
				</tr>
				<tr>
					<td>
						<div class="control-group <?php echo !empty($apeError)?'error':'';?>">
						<label class="control-label">Apellidos:</label>
					    <div class="controls">
					    <td>
					      	<input name="ape" type="text"  placeholder="Apellidos" value="<?php echo !empty($ape)?$ape:'';?>">
					      	<?php if (($apeError != null)) ?>
					      		<span class="help-inline"><?php echo $apeError;?></span>
					    </td>
					    </div>
						</div>
					</td>
				</tr>
				<tr>
					<td>
						<div class="control-group <?php echo !empty($corrError)?'error':'';?>">
						<label class="control-label">Correo Electrónico:</label>
					    <div class="controls">
					    <td>
					      	<input name="corr" type="email"  placeholder="Correo" value="<?php echo !empty($corr)?$corr:'';?>">
					      	<?php if (($corrError != null)) ?>
					      		<span class="help-inline"><?php echo $corrError;?></span>
					    </td>
					    </div>
						</div>
					</td>
				</tr>
				<tr>
					<td>
						<div class="control-group <?php echo !empty($proError)?'error':'';?>">
						<label class="control-label">Institución:</label>
					    <div class="controls">
					    <td>
					      	<input name="pro" type="text"  placeholder="Procedencia" value="<?php echo !empty($pro)?$pro:'';?>">
					      	<?php if (($proError != null)) ?>
					      		<span class="help-inline"><?php echo $proError;?></span>
					    </td>
					    </div>
						</div>
					</td>
				</tr>
				<tr>
					<td>
						<div class="control-group <?php echo !empty($conError)?'error':'';?>">
						<label class="control-label">Contraseña:</label>
					    <div class="controls">
					    <td>
					      	<input name="con" type="password"  placeholder="Contraseña" value="<?php echo !empty($con)?$con:'';?>">
					      	<?php if (($conError != null)) ?>
					      		<span class="help-inline"><?php echo $conError;?></span>
					    </td>
					    </div>
						</div>
					</td>
				</tr>
			</table>
		</div>
		
		<div class="registrar" align="right">
			<a href="index.php"><input type="button" value="Volver" class="guardar" align="right"/></a>
			<button type="submit" class="guardar">Registrar</button>
		</div>	
	</form>
	</body>
	
</html>
