<?php
session_start(); // Inicia la sesión

// Asigna el valor de la variable de sesión a la variable matricula
$matricula = $_SESSION['matricula'];

?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie-edge">
	<title>MisProyectos</title>
	<link rel="shortcut icon" href="/TC2005B_403_1/CRUD1/images/l2.jpg" type="image/x-icon">
	<link rel="stylesheet" href="/TC2005B_403_1/CRUD1/css/estilos3.css">
</head>

<body>

	<header>
		<table class="barra">
			<tr>
				<td> <img src="/TC2005B_403_1/CRUD1/images/expo1.jpg" alt="" class="logo"> </td>
				<td class="Inicio">
					<ul class="menu">
						<li><a href="index.php">Inicio</a></li>
					</ul>
				</td>
				<td>
					<ul class="actual">
					<?php echo '<li><a href="ProyectosAlumno.php?matricula=' . $matricula . '">Mis Proyectos</a></li>'; ?>
					</ul>
				</td>
			</tr>
		</table>
		
	</header>
		
		<table class="opciones">
			<tr>
				<div class="boton">
					<td>
						<a href="RegistrarProyecto.php"><input type="button" value="Registrar Proyecto" class="buton" /></a>
					</td>
				</div>
			</tr>
		</table>
		
		
	<section>
			
<table class="proyectos">
<?php
    include 'database.php';

        $pdo = Database::connect();

if ( !empty($_GET['matricula'])) {
    $matricula = $_GET['matricula'];
} else {
    header("Location: index.php");
}

    if ($matricula == null) {
        header("Location: index.php");
    }
    

$sql = 'SELECT MDP_proyecto.*, MDP_estatus.nombre AS estatus FROM MDP_proyecto
        INNER JOIN MDP_alumno_proyecto ON MDP_proyecto.id = MDP_alumno_proyecto.id_proyecto
        INNER JOIN MDP_alumno ON MDP_alumno_proyecto.matricula = MDP_alumno.matricula
        INNER JOIN MDP_estatus ON MDP_proyecto.id_estatus = MDP_estatus.id WHERE MDP_alumno.matricula = ?';

$stmt = $pdo->prepare($sql);
$stmt->execute([$matricula]);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
   $i = 0;
foreach ($results as $row) {
  // Código para mostrar los resultados
        if ($i % 2 == 0) { // Si el contador es par, empieza una nueva fila
            echo '<tr>';
        }
        echo '<td>';
        $frase = $row['imagen'];
        $subcadena = substr($frase, 32, 33); 
        echo '<img src="https://drive.google.com/uc?export=view&id='.$subcadena.'" alt="" class="imagen_router" height = 250>';
        echo '<a href="detalles.php?id='.$row['id'].'"><h4>'.$row['nombre'].'</h4></a>';
        
        $estatusClass = ($row['estatus'] == "Autorizado") ? "aproved" : "pendient";
        
        echo '<p class='.$estatusClass.'>'.$row['estatus'].'</p>';
        $estatusClass = "";
        echo '</td>';
        if ($i % 2 != 0) { // Si el contador es impar, cierra la fila
            echo '</tr>';
        }
        $i++;
}

    Database::disconnect();
?>

</table>


	</section>
	
	<aside>
	</aside>
	
</body>

	<footer class="text-center footer-style">
		
		<p class="tec">D.R. INSTITUTO TECNOLÓGICO Y DE ESTUDIOS SUPERIORES DE MONTERREY 2023</p>
		
	</footer>
	
</html>
