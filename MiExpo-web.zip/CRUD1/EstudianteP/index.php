<?php
session_start(); // Inicia la sesión

// Asigna el valor de la variable de sesión a la variable matricula
$matricula = $_SESSION['matricula'];

 include 'database.php';
        $pdo = Database::connect();
        $sql = 'SELECT MDP_extras.* FROM MDP_extras WHERE id=1';
        $i = 0;

        Database::disconnect();      
?>

    <?php
		$pdo = Database::connect();
		$query = 'SELECT anuncio AS anuncio FROM MDP_extras';
		foreach ($pdo->query($query) as $row) {
		if ($row['id']==$prof)
		"<option selected value='" . $row['id'] . "'>" . $row['anuncio'] . "</option>";
		 else
		"<option value='" . $row['id'] . "'>" . $row['anuncio'] . "</option>";
		
		$frase = $row['anuncio'];
		$subcadena = substr($frase, 32, 33); 
		}
	Database::disconnect();
   ?>
   

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Inicio </title>
		<link rel="shortcut icon" href="/TC2005B_403_1/CRUD1/images/l2.jpg" type="image/x-icon">
		<link rel="stylesheet" type"text/css" href="/TC2005B_403_1/CRUD1/css/estilos32.css">
		<script src="/TC2005B_403_1/CRUD1/js/script2.js"></script>
	</head>
	
	<body>
		
		<header>
		<table class="barra">
			<tr>
				<td> <img src="/TC2005B_403_1/CRUD1/images/expo1.jpg" alt="" class="logo"> </td>
				<td class="Inicio">
					<ul class="actual">
						<li><a href="index.php">Inicio</a></li>
					</ul>
				</td>
				<td>
					<ul class="menu">
						<?php echo '<li><a href="ProyectosAlumno.php?matricula=' . $matricula . '">Mis Proyectos</a></li>'; ?>
					</ul>
				</td>
			</tr>
		</table>
			
			<section class="textos-header">
			<table class="NUEVO">
				<tr>
				<td>
					<div class="rectangulo1">
					<h1> Bienvenido <br> <?php echo $matricula ?> </h1>
			   
					<div class="sesion">
						<img src="/TC2005B_403_1/CRUD1/images/perfil.png"  alt="" class="perfil">
						<br>
						<input type="button" value="Cerrar Sesión" class="buton" align="center" onclick="alerta()"/>
						
						<script>
							function alerta() {
								var opcion = confirm("¿Cerrar sesión?");
								if (opcion == true) {
									window.location.href = "/TC2005B_403_1/CRUD1/CerrarSesion.php";
								} else {
								// Si el usuario cancela, redirigimos a la página principal
									window.location.href = "index.php";
								}
							}
						</script>

						
					</div>
					
					
			   </div>
				</td>
				
					<td>
						<div class="anuncios">
							<img src=<?php echo "https://drive.google.com/uc?export=view&id=".$subcadena;?>  alt="" class="anuncio">
						</div>
					</td>
				</tr>
				
				</table>
				
			</section>
			<div class="wave" style="height: 150px; overflow: hidden;" ><svg viewBox="0 0 500 150" preserveAspectRatio="none" style="height: 100%; width: 100%;"><path d="M0.00,49.98 C282.44,51.81 294.86,50.83 500.00,49.98 L500.00,150.00 L0.00,150.00 Z" style="stroke: none; fill: #fff;"></path></svg></div>
			
		</header>
			
			<table class="info">
				<tr>
					<td><h3>En la Escuela de Ingeniería y Ciencias del Tec de Monterrey estamos convencidos de que el ingenio humano es lo que transforma al mundo.</h3><br>
					<p>En este evento podrás conocer muestras y exhibiciones de los proyectos más ingeniosos, innovadores y peculiares de estudiantes actuales de todas nuestras carreras de Ingeniería y Ciencias. También podrás participar en diversas actividades interactivas como las que se describen a continuación.</p></td>
					<td><iframe width="560" height="315" src="https://www.youtube.com/embed/E1fUpr9EA-Y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></td>
					
				</tr>
			</table>
			
		<div class="contenedor">
			
		</div>	
	
	</body>

	<footer class="text-center footer-style">
		
		<p class="siguenos">Síguenos</p>
		
		<hr width=400>
		
		<table class="redes">
			<tr>
				<td> <img src="/TC2005B_403_1/CRUD1/images/twitter.png" alt="" class="twitter"> </td>
				<td> <img src="/TC2005B_403_1/CRUD1/images/instagram.png" alt="" class="instagram"> </td>
				<td> <img src="/TC2005B_403_1/CRUD1/images/facebook.png" alt="" class="facebook"> </td>
				<td> <img src="/TC2005B_403_1/CRUD1/images/youtube.png" alt="" class="youtube"> </td>
			</tr>
		</table>
		
		<p class="tec">D.R. INSTITUTO TECNOLÓGICO Y DE ESTUDIOS SUPERIORES DE MONTERREY 2023</p>
		
	</footer>

	
</html>
