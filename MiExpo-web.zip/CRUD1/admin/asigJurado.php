<?php

	require 'database.php';

		$proError = null;
		$jurError = null;

	if ( !empty($_POST)) {

		$pro = $_POST['pro'];
		$jur = $_POST['jur'];

		// validate input
		$valid = true;

		if (empty($pro)) {
			$proError = 'Porfavor seleccione un proyecto';
			$valid = false;
		}
		if (empty($jur)) {
			$jurError = 'Porfavor seleccione un jurado';
			$valid = false;
		}


		// insert data
		if ($valid) {
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "INSERT INTO MDP_jurado_proyecto (id_jurado,id_proyecto,calificacion, comentario) values(?, ?, null, null)";
			$q = $pdo->prepare($sql);
			$q->execute(array($jur,$pro));
			Database::disconnect();
			header("Location: /TC2005B_403_1/CRUD1/admin/asignacion.php");
		}
	}
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8)>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie-edge">
	<title>Asignacion</title>
	<link rel="shortcut icon" href="/TC2005B_403_1/CRUD1/images/l2.jpg" type="image/x-icon">
	<link rel="stylesheet" href="/TC2005B_403_1/CRUD1/css/estilos36.css">
</head>

<body>
		
<header>
    <table class="barra">
        <tr>
            <td> <img src="/TC2005B_403_1/CRUD1/images/expo1.jpg" alt="" class="logo"> </td>
            <td class="Inicio">
                <ul class="menu">
                    <li><a href="index.php">Inicio</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="ProyectosActuales.php">Proyectos Actuales</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="Historial.php">Historial</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="jurados.php">Jurados</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="estudiantes.php">Estudiantes</a></li>
                </ul>
            </td>
            <td>
                <ul class="actual">
                    <li><a href="asignacion.php">Asignacion</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="ediciones.php">Edicion</a></li>
                </ul>
            </td>
        </tr>
    </table>
</header>
		
		
		
	<section>
	
	<form class="form-horizontal" action="asigJurado.php" method="POST">
		<div align="right">
			<a href="asignacion.php"><input type="button" value="Volver" class="buton1"/></a>
			<button type="submit" class="buton1">Asignar</button>
		</div>
		
		<table class="proyectos">
			<tr>
				<td><h4 class="pro">Asignar Jurado</h4></td>
			</tr>
			
			<tr>
				<td colspan=2 class="descripcion"> <h4 class="cat">Jurado <br>
						<div class="control-group <?php echo !empty($jurError)?'error':'';?>">
				    	<div class="controls">
	                       	<select name ="jur">
		                        <option value="">Seleccione un Jurado</option>
		                        <?php
							   		$pdo = Database::connect();
							   		$query = 'SELECT *,CONCAT(nombre," ",apellidos) AS nombre_completo FROM MDP_jurado';
			 				   		foreach ($pdo->query($query) as $row) {
		                        		if ($row['id']==$jur)
		                        			echo "<option selected value='" . $row['id'] . "'>" . $row['nombre_completo'] . "</option>";
		                        		else
		                        			echo "<option value='" . $row['id'] . "'>" . $row['nombre_completo'] . "</option>";
			   						}
			   						Database::disconnect();
			  					?>
                            </select>
					      	<?php if (($jurError) != null) ?>
					      		<span class="help-inline"><?php echo $jurError;?></span>
						</div>
					</div>
				 

				<h4 class="cat">Proyecto <br>
						<div class="control-group <?php echo !empty($proError)?'error':'';?>">
				    	<div class="controls">
	                       	<select name ="pro">
		                        <option value="">Seleccione un proyecto</option>
		                        <?php
							   		$pdo = Database::connect();
							   		$query = 'SELECT * FROM MDP_proyecto';
			 				   		foreach ($pdo->query($query) as $row) {
		                        		if ($row['id']==$pro)
		                        			echo "<option selected value='" . $row['id'] . "'>" . $row['nombre'] . "</option>";
		                        		else
		                        			echo "<option value='" . $row['id'] . "'>" . $row['nombre'] . "</option>";
			   						}
			   						Database::disconnect();
			  					?>
                            </select>
					      	<?php if (($proError) != null) ?>
					      		<span class="help-inline"><?php echo $proError;?></span>
						</div>
					</div>
				 </td>
			</tr>

		
		</table>
	</form>
	
	</section>
	

</body>

</html>

