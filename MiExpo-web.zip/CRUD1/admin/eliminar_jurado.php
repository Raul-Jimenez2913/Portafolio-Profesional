
<?php
	require 'database.php';
	$id = 0;
	if ( !empty($_GET['id'])) {
		$id = $_REQUEST['id'];
	}

	if ( !empty($_POST)) {
		// keep track post values
		$id = $_POST['id'];
		// delete data
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "DELETE FROM MDP_jurado WHERE id = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		Database::disconnect();
		header("Location: jurados.php");
	}
?>

<!DOCTYPE html>
<html lang="es">
	<head>
	    <meta 	charset="utf-8">
	    <link   href=	"/TC2005B_403_1/CRUD1/css/bootstrap.min.css" rel="stylesheet">
	    <script src=	"/TC2005B_403_1/CRUD1/bootstrap.min.js"></script>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
	    <meta http-equiv="X-UA-Compatible" content="ie-edge">
	    <title>MisProyectos</title>
	    <link rel="shortcut icon" href="/TC2005B_403_1/CRUD1/images/l2.jpg" type="image/x-icon">
	    <link rel="stylesheet" href="/TC2005B_403_1/CRUD1/css/estilos22.css">
</head>

	</head>

	<body>
	<header>
    <table class="barra">
        <tr>
            <td> <img src="/TC2005B_403_1/CRUD1/images/expo1.jpg" alt="" class="logo"> </td>
            <td class="Inicio">
                <ul class="menu">
                    <li><a href="index.php">Inicio</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="ProyectosActuales.php">Proyectos Actuales</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="Historial.php">Historial</a></li>
                </ul>
            </td>
            <td>
                <ul class="actual">
                    <li><a href="jurados.php">Jurados</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="estudiantes.php">Estudiantes</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="asignacion.php">Asignacion</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="ediciones.php">Edicion</a></li>
                </ul>
            </td>
        </tr>
    </table>
</header>
		
	    <div class="container">
	    	<div class="span10 offset1">
	    		<div class="row">
			    	<h3>Eliminar Juez</h3>
			    </div>

			    <form class="form-horizontal" action="eliminar_jurado.php" method="post">
		    		<input type="hidden" name="id" value="<?php echo $id;?>"/>
					<p class="alert alert-error">Estas seguro que quieres eliminar este juez?</p>
					<div class="form-actions">
						<button type="submit" class="btn btn-danger">Si</button>
						<a class="btn" href="jurados.php">No</a>
					</div>
				</form>
			</div>
	  </div> <!-- /container -->
	</body>
</html>
