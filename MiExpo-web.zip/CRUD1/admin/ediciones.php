<?php
    session_start();
    require 'database.php';

    if (!empty($_POST)) {
        // Recuperar valores del formulario
        $nombre = $_POST['nombre'];
        $id = $_POST['id'];

        // Conectar a la base de datos
        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Validar si el ID ya existe en la tabla
        $q = $pdo->prepare("SELECT COUNT(*) AS count FROM MDP_edicion WHERE id = ?");
        $q->execute(array($id));
        $result = $q->fetch(PDO::FETCH_ASSOC);
        if ($result['count'] > 0) {
            // Guardar mensaje de error en variable de sesión
            $_SESSION['mensaje'] = 'El ID ya existe en la base de datos';
        } else {
            // Preparar consulta SQL
            $sql = "INSERT INTO MDP_edicion (id, nombre, estado) VALUES (:id, :nombre, 'inactivo')";
            $q = $pdo->prepare($sql);

            // Iniciar una transacción
            $pdo->beginTransaction();

            try {
                // Ejecutar consulta con los nuevos valores
                if ($q->execute(array(':nombre' => $nombre, ':id' => $id))) {
                    // Guardar mensaje de éxito en variable de sesión
                    $_SESSION['mensaje'] = 'La edición se ha registrado correctamente';

                    // Actualizar el estado de todas las ediciones excepto la que se acaba de insertar a "inactivo"
                    $sql = "UPDATE MDP_edicion SET estado = 'inactivo' WHERE id != ?";
                    $q = $pdo->prepare($sql);
                    $q->execute(array($id));

                    // Actualizar el estado de la edición recién insertada a "activo"
                    $sql = "UPDATE MDP_edicion SET estado = 'activo' WHERE id = ?";
                    $q = $pdo->prepare($sql);
                    $q->execute(array($id));

                    // Confirmar la transacción
                    $pdo->commit();

                } else {
                    // Guardar mensaje de error en variable de sesión
                    $_SESSION['mensaje'] = 'Error al registrar la edición';
                }

            } catch (Exception $e) {
                // Deshacer la transacción en caso de error
                $pdo->rollBack();
                $_SESSION['mensaje'] = 'Error al registrar la edición';
            }
        }

        // Cerrar conexión y redirigir a la página actual
        Database::disconnect();
        header("Location: {$_SERVER['PHP_SELF']}");
        exit();
    }
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie-edge">
    <title>Registar Edicion</title>
    <link rel="shortcut icon" href="/TC2005B_403_1/CRUD1/images/l2.jpg" type="image/x-icon">
    <link rel="stylesheet" href="/TC2005B_403_1/CRUD1/css/estilos11.css">
</head>

<body>
<header>
    <table class="barra">
        <tr>
            <td> <img src="/TC2005B_403_1/CRUD1/images/expo1.jpg" alt="" class="logo"> </td>
            <td class="Inicio">
                <ul class="menu">
                    <li><a href="index.php">Inicio</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="ProyectosActuales.php">Proyectos Actuales</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="Historial.php">Historial</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="jurados.php">Jurados</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="estudiantes.php">Estudiantes</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="asignacion.php">Asignacion</a></li>
                </ul>
            </td>
            <td>
                <ul class="actual">
                    <li><a href="ediciones.php">Edicion</a></li>
                </ul>
            </td>
        </tr>
    </table>
</header>

<section>
    <div class="proyectos">
        <h1>Crear y asignar edición de ExpoIngenierías</h1>
    </div>
</section>

	
	<div align="center">
	<?php
        // Mostrar mensaje si existe
	if (isset($_SESSION['mensaje'])) {
		echo '<p>' . $_SESSION['mensaje'] . '</p>';
		unset($_SESSION['mensaje']);
	}
    ?>
    <br>
	<form action="ediciones.php" method="POST">

		<label for="nombre">Nombre de la Edición:</label>
		<input type="text" id="nombre" name="nombre" required><br><br>

		<label for="id">ID de la Edición:</label>
		<input type="text" id="id" name="id" required maxlength="5"><br><br>


		<a href="index.php"><input type="button" value="Volver" class="guardar" align="center"/></a>
		  <button type="submit" class="guardar">Crear</button>
	</form>
	</div>
</body>
</html>
