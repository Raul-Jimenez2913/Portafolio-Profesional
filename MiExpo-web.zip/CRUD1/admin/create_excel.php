<?php
	header("Content-Type: application/xls");    
	header("Content-Disposition: attachment; filename=Historial_" . date('Y:m:d:m:s').".xls");
	
			include 'database.php';
			$pdo = Database::connect();
		   	$sql = 'SELECT MDP_proyecto.*, MDP_estatus.nombre AS estatus, MDP_categoria_area.nombre AS categoria, MDP_categoria_evaluacion.nombre AS evaluacion, MDP_Orden_calificacion.promedio, MDP_profesor.nombre AS profesor, MDP_profesor.apellidos AS apellidos, MDP_proyecto.Id_unidad_formacion AS uf, MDP_proyecto.id_edicion as periodo FROM MDP_proyecto INNER JOIN MDP_estatus ON MDP_proyecto.id_estatus = MDP_estatus.id INNER JOIN MDP_categoria_area ON MDP_proyecto.id_area = MDP_categoria_area.id INNER JOIN MDP_profesor ON MDP_proyecto.id_profesor = MDP_profesor.nomina INNER JOIN MDP_categoria_evaluacion ON MDP_proyecto.id_evaluacion = MDP_categoria_evaluacion.id INNER JOIN MDP_Orden_calificacion ON MDP_proyecto.id = MDP_Orden_calificacion.id';

		
	Database::disconnect();
		?> 
		
<table class="tabla1">
			<tr>
				<th>ID</th>
				<th>Nombre</th>
				<th>Matrículas equipo</th>
				<th>Calificación</th>
				<th>Profesor</th>
				<th>ID jurados</th>
				<th>Estatus</th>
				<th>Área</th>
				<th>Evaluación</th>
				<th>UF</th>
				<th>Periodo</th>
			</tr>
			
			<?php
			
		   	foreach ($pdo->query($sql) as $row) {
				echo '<tr>';
				    	echo '<td>'. $row['id'] . '</td>';	    					 			
				    	echo '<td>'. $row['nombre'] . '</td>';
			                echo '<td>'. $row['participantes'] . '</td>';
			                echo '<td>'. $row['promedio'].'</td>';
			                echo '<td>'. $row['profesor']." ".$row['apellidos'].'</td>';	    				
			                echo '<td>'. $row['jurado'] . '</td>';
			                echo '<td>'. $row['estatus'] . '</td>';		    
			                echo '<td>'. $row['categoria'] . '</td>';	    				
			                echo '<td>'. $row['evaluacion'] . '</td>';	    				
			                				
			                echo '<td>'. $row['uf'] . '</td>';
			                echo '<td>'. $row['periodo'] . '</td>';	   
				echo '</tr>';
							    }
		   	
		?>  	
		</table>
