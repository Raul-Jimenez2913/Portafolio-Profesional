<?php

	require 'database.php';

	$id = null;
	if ( !empty($_GET['id'])) {
		$id = $_REQUEST['id'];
	}

	if ( $id==null ) {
		header("Location: jurados.php");
	}

	if ( !empty($_POST)) {
		$matriculaError   = null;
		$nomError  = null;
		$apeError  = null;
		$corrError  = null;
		$proError  = null;
		
		// keep track post values
		$matricula   = $_POST['matricula'];
		$nom  = $_POST['nom'];
		$ape  = $_POST['ape'];
		$corr  = $_POST['corr'];
		$pro  = $_POST['pro'];
		
		
		/// validate input
		$valid = true;
		if (empty($id)) {
			$idError = 'Porfavor ingrese la matrícula';
			$valid = false;
		}
		
		if (empty($nom)) {
			$nomError = 'Porfavor escribe un nombre';
			$valid = false;
		}

		if (empty($ape)) {
			$apeError = 'Porfavor ingrese apellidos';
			$valid = false;
		}
		
		if (empty($corr)) {
			$corrError = 'Porfavor escribe un correo electrónico';
			$valid = false;
		}
		if (empty($pro)) {
			$proError = 'Porfavor escribe la procedencia';
			$valid = false;
		}

		// update data
		if ($valid) {
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "UPDATE MDP_jurado SET id = ?, nombre = ?, apellidos = ?, correo = ?, procedencia = ? WHERE id = ?";
			$q = $pdo->prepare($sql);
			$q->execute(array($id,$nom,$ape,$corr,$pro,$id));
			Database::disconnect();
			header("Location: jurados.php");
		}
	}
	else {
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM MDP_jurado WHERE id = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$data= $q->fetch(PDO::FETCH_ASSOC);
		$id  = $data['id'];
		$nom = $data['nombre'];
		$ape= $data['apellidos'];
		$corr = $data['correo'];
		$pro  = $data['procedencia'];
		Database::disconnect();
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>EditarProyecto </title>
		<link rel="shortcut icon" href="/TC2005B_403_1/CRUD1/images/l2.jpg" type="image/x-icon">
		<link rel="stylesheet" type"text/css" href="/TC2005B_403_1/CRUD1/css/estilos2.css">
		<script src="/TC2005B_403_1/CRUD1/js/script2.js"></script>
	</head>
	
	<body>
		
		<header>
    <table class="barra">
        <tr>
            <td> <img src="/TC2005B_403_1/CRUD1/images/expo1.jpg" alt="" class="logo"> </td>
            <td class="Inicio">
                <ul class="menu">
                    <li><a href="index.php">Inicio</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="ProyectosActuales.php">Proyectos Actuales</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="Historial.php">Historial</a></li>
                </ul>
            </td>
            <td>
                <ul class="actual">
                    <li><a href="jurados.php">Jurados</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="estudiantes.php">Estudiantes</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="asignacion.php">Asignacion</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="ediciones.php">Edicion</a></li>
                </ul>
            </td>
        </tr>
    </table>
</header>

			<section class="textos-header">
				<h1> Editar Juez </h1>
				<h1> Id: <?php echo $data['id'];?> </h1>
			</section>
			<div class="wave" style="height: 150px; overflow: hidden;" ><svg viewBox="0 0 500 150" preserveAspectRatio="none" style="height: 100%; width: 100%;"><path d="M0.00,49.98 C282.44,51.81 294.86,50.83 500.00,49.98 L500.00,150.00 L0.00,150.00 Z" style="stroke: none; fill: #fff;"></path></svg></div>
		</header>
		
		
		<div class="contenedor">
			<form class="form-horizontal" action="EditarJuez.php?id=<?php echo $id?>" method="post">
					<table class="tabla">
						<tr>
							<td>Id:</td>
							<td>
							<div class="control-group <?php echo !empty($idError)?'error':'';?>">
							<div class="controls">
					      	<input name="id" type="text" readonly placeholder="id" value="<?php echo !empty($id)?$id:''; ?>">
					      	<?php if (!empty($idError)): ?>
					      		<span class="help-inline"><?php echo $idError;?></span>
					      	<?php endif; ?>
					    </div>
						</div>
						</td>
						</tr>
						<tr>
							<td>Nombre:</td>
							<td>	
							<div class="control-group <?php echo !empty($nomError)?'error':'';?>">
							<div class="controls">
					      	<input name="nom" type="text" placeholder="nombre" value="<?php echo !empty($nom)?$nom:'';?>">
					      	<?php if (!empty($nomError)): ?>
					      		<span class="help-inline"><?php echo $nomError;?></span>
					      	<?php endif;?>
							</div>
							</div>
							</td>
						</tr>
						<tr>
							<td>Apellidos:</td>
							<td>	
							<div class="control-group <?php echo !empty($apeError)?'error':'';?>">
							<div class="controls">
					      	<input name="ape" type="text" placeholder="apellidos" value="<?php echo !empty($ape)?$ape:'';?>">
					      	<?php if (!empty($apeError)): ?>
					      		<span class="help-inline"><?php echo $apeError;?></span>
					      	<?php endif;?>
							</div>
							</div>
							</td>
						</tr>
						<tr>
							<td>Correo Electrónico:</td>
							<td>	
							<div class="control-group <?php echo !empty($corrError)?'error':'';?>">
							<div class="controls">
					      	<input name="corr" type="email" placeholder="correo" value="<?php echo !empty($corr)?$corr:'';?>">
					      	<?php if (!empty($corrError)): ?>
					      		<span class="help-inline"><?php echo $corrError;?></span>
					      	<?php endif;?>
							</div>
							</div>
							</td>
						</tr>
						<tr>
							<td>Procedencia:</td>
							<td>
							<div class="control-group <?php echo !empty($proError)?'error':'';?>">
							<div class="controls">
					      	<input name="pro" type="text" placeholder="procedencia" value="<?php echo !empty($pro)?$pro:'';?>">
					      	<?php if (!empty($proError)): ?>
					      		<span class="help-inline"><?php echo $proError;?></span>
					      	<?php endif;?>
							</div>
							</div>
							</td>
						</tr>

						<tr>
						</tr>
							<td>
								<a href="jurados.php"><input type="button" value="Volver" class="guardar" align="right"/></a>
								<button type="submit" class="guardar">Actualizar</button>
							</td>
						</tr>
					</table>
					

			</form>
		</div>
				
	</body>
	
	<footer class="text-center footer-style">
		
		<p class="tec">D.R. INSTITUTO TECNOLÓGICO Y DE ESTUDIOS SUPERIORES DE MONTERREY 2023</p>
		
	</footer>
	
</html>
