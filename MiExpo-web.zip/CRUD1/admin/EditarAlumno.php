<?php

	require 'database.php';

	$matricula = null;
	if ( !empty($_GET['matricula'])) {
		$id = $_REQUEST['matricula'];
	}

	if ( $id==null ) {
		header("Location: estudiantes.php");
	}

	if ( !empty($_POST)) {
		$matriculaError   = null;
		$nomError  = null;
		$apeError  = null;
		$corrError  = null;
		$fecError  = null;
		$carError  = null;
		
		// keep track post values
		$matricula   = $_POST['matricula'];
		$nom  = $_POST['nom'];
		$ape  = $_POST['ape'];
		$corr  = $_POST['corr'];
		$fec  = $_POST['fec'];
		$car  = $_POST['car'];
		
		
		/// validate input
		$valid = true;
		if (empty($matricula)) {
			$matriculaError = 'Porfavor ingrese la matrícula';
			$valid = false;
		}
		
		if (empty($nom)) {
			$nomError = 'Porfavor escribe un nombre';
			$valid = false;
		}

		if (empty($ape)) {
			$apeError = 'Porfavor ingrese apellidos';
			$valid = false;
		}
		
		if (empty($corr)) {
			$corrError = 'Porfavor escribe un correo electrónico';
			$valid = false;
		}
		if (empty($fec)) {
			$fecError = 'Porfavor escribe la fecha de ingreso';
			$valid = false;
		}
		if (empty($car)) {
			$carError = 'Porfavor ingrese las siglas de la carrera';
			$valid = false;
		}

		// update data
		if ($valid) {
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "UPDATE MDP_alumno SET matricula = ?, nombre = ?, apellidos = ?, correo = ?, fecha_ingreso = ?, id_carrera = ? WHERE matricula = ?";
			$q = $pdo->prepare($sql);
			$q->execute(array($matricula,$nom,$ape,$corr,$fec,$car,$matricula));
			Database::disconnect();
			header("Location: estudiantes.php");
		}
	}
	else {
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM MDP_alumno WHERE matricula = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$data= $q->fetch(PDO::FETCH_ASSOC);
		$matricula  = $data['matricula'];
		$nom = $data['nombre'];
		$ape= $data['apellidos'];
		$corr = $data['correo'];
		$fec  = $data['fecha_ingreso'];
		$car  = $data['id_carrera'];
		Database::disconnect();
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>EditarProyecto </title>
		<link rel="shortcut icon" href="/TC2005B_403_1/CRUD1/images/l2.jpg" type="image/x-icon">
		<link rel="stylesheet" type"text/css" href="/TC2005B_403_1/CRUD1/css/estilos2.css">
		<script src="/TC2005B_403_1/CRUD1/js/script2.js"></script>
	</head>
	
	<body>
		
		<header>
    <table class="barra">
        <tr>
            <td> <img src="/TC2005B_403_1/CRUD1/images/expo1.jpg" alt="" class="logo"> </td>
            <td class="Inicio">
                <ul class="menu">
                    <li><a href="index.php">Inicio</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="ProyectosActuales.php">Proyectos Actuales</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="Historial.php">Historial</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="jurados.php">Jurados</a></li>
                </ul>
            </td>
            <td>
                <ul class="actual">
                    <li><a href="estudiantes.php">Estudiantes</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="asignacion.php">Asignacion</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="ediciones.php">Edicion</a></li>
                </ul>
            </td>
        </tr>
    </table>
</header>
		
			<section class="textos-header">
				<h1> Editar Estudiante </h1>
				<h1> Matrícula: <?php echo $data['matricula'];?> </h1>
			</section>
			<div class="wave" style="height: 150px; overflow: hidden;" ><svg viewBox="0 0 500 150" preserveAspectRatio="none" style="height: 100%; width: 100%;"><path d="M0.00,49.98 C282.44,51.81 294.86,50.83 500.00,49.98 L500.00,150.00 L0.00,150.00 Z" style="stroke: none; fill: #fff;"></path></svg></div>
		</header>
		
		
		<div class="contenedor">
			<form class="form-horizontal" action="EditarAlumno.php?id=<?php echo $id?>" method="post">
					<table class="tabla">
						<tr>
							<td>Matrícula:</td>
							<td>
							<div class="control-group <?php echo !empty($matriculaError)?'error':'';?>">
							<div class="controls">
					      	<input name="matricula" type="text" readonly placeholder="matricula" value="<?php echo !empty($matricula)?$matricula:''; ?>">
					      	<?php if (!empty($matriculaError)): ?>
					      		<span class="help-inline"><?php echo $matriculaError;?></span>
					      	<?php endif; ?>
					    </div>
						</div>
						</td>
						</tr>
						<tr>
							<td>Nombre:</td>
							<td>	
							<div class="control-group <?php echo !empty($nomError)?'error':'';?>">
							<div class="controls">
					      	<input name="nom" type="text" placeholder="nombre" value="<?php echo !empty($nom)?$nom:'';?>">
					      	<?php if (!empty($nomError)): ?>
					      		<span class="help-inline"><?php echo $nomError;?></span>
					      	<?php endif;?>
							</div>
							</div>
							</td>
						</tr>
						<tr>
							<td>Apellidos:</td>
							<td>	
							<div class="control-group <?php echo !empty($apeError)?'error':'';?>">
							<div class="controls">
					      	<input name="ape" type="text" placeholder="apellidos" value="<?php echo !empty($ape)?$ape:'';?>">
					      	<?php if (!empty($apeError)): ?>
					      		<span class="help-inline"><?php echo $apeError;?></span>
					      	<?php endif;?>
							</div>
							</div>
							</td>
						</tr>
						<tr>
							<td>Correo Electrónico:</td>
							<td>	
							<div class="control-group <?php echo !empty($corrError)?'error':'';?>">
							<div class="controls">
					      	<input name="corr" type="email" placeholder="correo" value="<?php echo !empty($corr)?$corr:'';?>">
					      	<?php if (!empty($corrError)): ?>
					      		<span class="help-inline"><?php echo $corrError;?></span>
					      	<?php endif;?>
							</div>
							</div>
							</td>
						</tr>
						<tr>
							<td>Fecha de ingreso:</td>
							<td>
							<div class="control-group <?php echo !empty($fecError)?'error':'';?>">
							<div class="controls">
					      	<input name="fec" type="date" placeholder="fecha" value="<?php echo !empty($fec)?$fec:'';?>">
					      	<?php if (!empty($fecError)): ?>
					      		<span class="help-inline"><?php echo $fecError;?></span>
					      	<?php endif;?>
							</div>
							</div>
							</td>
						</tr>

						<tr>
							<td>Carrera:</td>
							<td> 
							<div class="control-group <?php echo !empty($carError)?'error':'';?>">
							<div class="controls">
							<select name ="car">
		                        <option value="<?php echo !empty($car)?$car:''; ?>">Seleccionae una Carrera</option>
		                        <?php
							   		$pdo = Database::connect();
							   		$query = 'SELECT * FROM MDP_carrera';
			 				   		foreach ($pdo->query($query) as $row) {
		                        		if ($row['id_carrera']==$car)
		                        			echo "<option selected value='" . $row['id_carrera'] . "'>" . $row['nombre'] . "</option>";
		                        		else
		                        			echo "<option value='" . $row['id_carrera'] . "'>" . $row['nombre'] . "</option>";
			   						}
			   						Database::disconnect();
			  					?>
                            </select>
					      	<?php if (!empty($carError)): ?>
					      		<span class="help-inline"><?php echo $carError;?></span>
					      	<?php endif;?>
							</div>
							</div>
							</td>
						</tr>
							</td>
						</tr>
							<td>
								<a href="estudiantes.php"><input type="button" value="Volver" class="guardar" align="right"/></a>
								<button type="submit" class="guardar">Actualizar</button>
							</td>
						</tr>
					</table>
					

			</form>
		</div>
				
	</body>
	
	<footer class="text-center footer-style">
		
		<p class="tec">D.R. INSTITUTO TECNOLÓGICO Y DE ESTUDIOS SUPERIORES DE MONTERREY 2023</p>
		
	</footer>
	
</html>
