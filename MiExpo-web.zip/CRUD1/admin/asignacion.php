<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8)>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie-edge">
	<title>MisProyectos</title>
	<link rel="shortcut icon" href="/TC2005B_403_1/CRUD1/images/l2.jpg" type="image/x-icon">
	<link rel="stylesheet" href="/TC2005B_403_1/CRUD1/css/estilos15.css">
</head>

<body>

<header>
    <table class="barra">
        <tr>
            <td> <img src="/TC2005B_403_1/CRUD1/images/expo1.jpg" alt="" class="logo"> </td>
            <td class="Inicio">
                <ul class="menu">
                    <li><a href="index.php">Inicio</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="ProyectosActuales.php">Proyectos Actuales</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="Historial.php">Historial</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="jurados.php">Jurados</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="estudiantes.php">Estudiantes</a></li>
                </ul>
            </td>
            <td>
                <ul class="actual">
                    <li><a href="asignacion.php">Asignacion</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="ediciones.php">Edicion</a></li>
                </ul>
            </td>
        </tr>
    </table>
</header>
			
	<section>
	
	<div align="left" style="margin-left: 75px; margin-top: 25px;">
			<a href="asigJurado.php"><input type="button" value="Asignar Jurado" class="buton"/></a>
			
		</div>
		
			<table class="proyectos">
			 <?php
        include 'database.php';
        $pdo = Database::connect();
        $sql = 'SELECT MDP_proyecto.*, MDP_estatus.nombre AS estatus FROM MDP_proyecto INNER JOIN MDP_estatus ON MDP_proyecto.id_estatus = MDP_estatus.id';
        $i = 0;
        foreach ($pdo->query($sql) as $row) {
            if ($i % 2 == 0) { // Si el contador es par, empieza una nueva fila
                echo '<tr>';
            }
            echo '<td>';
            $frase = $row['imagen'];
	    $subcadena = substr($frase, 32, 33); 
            echo '<img src="https://drive.google.com/uc?export=view&id='.$subcadena.'" alt="" class="imagen_router" height = 250>';
            echo '<a href="verAdmin.php?id='.$row['id'].'"><h4>'.$row['nombre'].'</h4></a>';
            
            //$estatusClass = ($row['estatus'] == "Autorizado") ? "aproved" : ($row['estatus'] == "Pendiente") ? "pendient" : "rechazado";
            $estatusClass = ($row['estatus'] == "Autorizado") ? "aproved" : "pendient";
            
            echo '<p class='.$estatusClass.'>'.$row['estatus'].'</p>';
            $estatusClass = "";
            echo '</td>';
            if ($i % 2 != 0) { // Si el contador es impar, cierra la fila
                echo '</tr>';
            }
            $i++;
        }
        if ($i % 2 != 0) { // Si el último elemento dejó una fila abierta, ciérrala
            echo '</tr>';
        }
        Database::disconnect();
    ?>
			</table>
			
	</section>

	
</body>

	<footer class="text-center footer-style">
		
		<p class="tec">D.R. INSTITUTO TECNOLÓGICO Y DE ESTUDIOS SUPERIORES DE MONTERREY 2023</p>
		
	</footer>
	
</html>
