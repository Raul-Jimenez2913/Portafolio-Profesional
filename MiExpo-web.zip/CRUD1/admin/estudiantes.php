<?php
			include 'database.php';
			$pdo = Database::connect();
			$sql = 'SELECT MDP_alumno.* FROM MDP_alumno';
			
			// Contar todos los alumnos
			$query = "SELECT COUNT(*) AS total FROM MDP_alumno";
			$stmt = $pdo->query($query);
			$resultado = $stmt->fetch(PDO::FETCH_ASSOC);
			
			// Obtener periodo
			$query2 = "SELECT id AS periodo FROM MDP_edicion WHERE id='FJ 23'";
			$stmt2 = $pdo->query($query2);
			$resultado2 = $stmt2->fetch(PDO::FETCH_ASSOC);
			
			Database::disconnect();
			?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8)>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie-edge">
	<title>Estudiantes</title>
	<link rel="shortcut icon" href="/TC2005B_403_1/CRUD1/images/l2.jpg" type="image/x-icon">
	<link rel="stylesheet" href="/TC2005B_403_1/CRUD1/css/estilos19.css">
</head>

<body>
		
<header>
    <table class="barra">
        <tr>
            <td> <img src="/TC2005B_403_1/CRUD1/images/expo1.jpg" alt="" class="logo"> </td>
            <td class="Inicio">
                <ul class="menu">
                    <li><a href="index.php">Inicio</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="ProyectosActuales.php">Proyectos Actuales</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="Historial.php">Historial</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="jurados.php">Jurados</a></li>
                </ul>
            </td>
            <td>
                <ul class="actual">
                    <li><a href="estudiantes.php">Estudiantes</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="asignacion.php">Asignacion</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="ediciones.php">Edicion</a></li>
                </ul>
            </td>
        </tr>
    </table>
</header>
		
		
		
	<section>
		<div class="proyectos">
			<h1>ESTUDIANTES</h1>
		</div>
		
		<table class="contador">
			<tr>
				<td class="letra">Periodo</td>
				<td class="letra">Alumnos Registrados</td>
			</tr>
			<tr>
				<td><?php echo $resultado2['periodo']?></td>
				<td><?php echo $resultado['total']?></td>
			</tr>
		</table>
		
	</section>
	
	<div class="tabla">
		<table class="tabla1">
			<tr>
				<th>Matrícula</th>
				<th>Nombre</th>
				<th>Apellidos</th>
				<th>Fecha de ingreso</th>
				<th>Carrera</th>
			</tr>
			
			<?php
			
			
			foreach ($pdo->query($sql) as $row) {
			echo '<tr>';
			    	echo '<td>'. $row['matricula'] . '</td>';
			    	echo '<td>'. $row['nombre'] . '</td>';
			    	echo '<td>'. $row['apellidos'] . '</td>';
			        echo '<td>'. $row['fecha_ingreso'] . '</td>';
			        echo '<td>'. $row['id_carrera'] . '</td>';
			        echo '<td width=200>';
			    	echo '<a href="EditarAlumno.php?matricula='.$row['matricula'].'">Editar</a>';
			    	echo '&nbsp;';
			    	echo '<a href="eliminar_proyect.php?matricula='.$row['matricula'].'">Eliminar</a>';
			    	echo '</td>';
			echo '</tr>';
								}
			Database::disconnect();
			?>
			
		</table>
	</div>
		
</body>
	
</html>
