<?php
	require 'database.php';

	if (!empty($_POST)) {
	  // Recuperar valores del formulario
	  $id = $_POST['id'];
	  $mapa = $_POST['mapa'];
	  $anuncio = $_POST['anuncio'];

	  // Conectar a la base de datos
	  $pdo = Database::connect();
	  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	  // Preparar consulta SQL
	  $sql = "UPDATE MDP_extras SET mapa = :mapa, anuncio = :anuncio WHERE id = 1";
	  $q = $pdo->prepare($sql);

	  // Ejecutar consulta con los nuevos valores
	  $q->execute(array(
	    ':mapa' => $mapa,
	    ':anuncio' => $anuncio,
	  ));

	  // Cerrar conexión y redirigir a la página de éxito
	  Database::disconnect();
	  header("Location: index.php");
}
?>



<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie-edge">
	<title>Editar</title>
	<link rel="shortcut icon" href="/TC2005B_403_1/CRUD1/images/l2.jpg" type="image/x-icon">
	<link rel="stylesheet" href="/TC2005B_403_1/CRUD1/css/estilos11.css">
</head>


<body>
		
<header>
    <table class="barra">
        <tr>
            <td> <img src="/TC2005B_403_1/CRUD1/images/expo1.jpg" alt="" class="logo"> </td>
            <td class="Inicio">
                <ul class="actual">
                    <li><a href="index.php">Inicio</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="ProyectosActuales.php">Proyectos Actuales</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="Historial.php">Historial</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="jurados.php">Jurados</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="estudiantes.php">Estudiantes</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="asignacion.php">Asignacion</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="ediciones.php">Edicion</a></li>
                </ul>
            </td>
        </tr>
    </table>
</header>
		
		
	<section>
		<div class="proyectos">
			<h1>Insertar Imágenes</h1>
		</div>

	</section>
	
	<div align="center">
	<form action="imagenes.php" method="POST">

		  <label for="mapa">Mapa:</label>
		  <input type="text" id="mapa" name="mapa" required><br><br>

		  <label for="anuncio">Anuncio:</label>
		  <input type="text" id="anuncio" name="anuncio" required><br><br>
		
		<a href="index.php"><input type="button" value="Volver" class="guardar" align="center"/></a>
		  <button type="submit" class="guardar">Actualizar</button>
	</form>
	</div>

</body>
</html>
