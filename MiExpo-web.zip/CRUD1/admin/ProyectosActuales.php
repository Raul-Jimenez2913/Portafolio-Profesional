<?php
			include 'database.php';
			$pdo = Database::connect();
		   	$sql = 'SELECT MDP_proyecto.*, 
       MDP_estatus.nombre AS estatus, 
       MDP_categoria_area.nombre AS categoria, 
       MDP_categoria_evaluacion.nombre AS evaluacion,
       MDP_Orden_calificacion.promedio, 
       MDP_profesor.nombre AS profesor, 
       MDP_profesor.apellidos AS apellidos 
	FROM MDP_proyecto 
	INNER JOIN MDP_estatus ON MDP_proyecto.id_estatus = MDP_estatus.id 
	INNER JOIN MDP_categoria_area ON MDP_proyecto.id_area = MDP_categoria_area.id 
	INNER JOIN MDP_profesor ON MDP_proyecto.id_profesor = MDP_profesor.nomina 
	INNER JOIN MDP_categoria_evaluacion ON MDP_proyecto.id_evaluacion = MDP_categoria_evaluacion.id 
	LEFT JOIN MDP_Orden_calificacion ON MDP_proyecto.id = MDP_Orden_calificacion.id';
		   	
		   	// Contar todos los proyectos
			$query = "SELECT COUNT(*) AS total FROM MDP_proyecto";
			$stmt = $pdo->query($query);
			$resultado = $stmt->fetch(PDO::FETCH_ASSOC);
			
			// Contar todos los proyectos PENDIENTES
			$query2 = "SELECT COUNT(*) AS pendientes FROM MDP_proyecto WHERE id_estatus = 1";
			$stmt2 = $pdo->query($query2);
			$resultado2 = $stmt2->fetch(PDO::FETCH_ASSOC);
			
			// Contar todos los proyectos AUTORIZADOS
			$query3 = "SELECT COUNT(*) AS autorizados FROM MDP_proyecto WHERE id_estatus = 2";
			$stmt3 = $pdo->query($query3);
			$resultado3 = $stmt3->fetch(PDO::FETCH_ASSOC);
			
			// Contar todos los proyectos RECHAZADOS
			$query4 = "SELECT COUNT(*) AS rechazados FROM MDP_proyecto WHERE id_estatus = 3";
			$stmt4 = $pdo->query($query4);
			$resultado4 = $stmt4->fetch(PDO::FETCH_ASSOC);
			
			//*******************************************
			// Contar todos los proyectos CYBER
			$query5 = "SELECT COUNT(*) AS cyber FROM MDP_proyecto WHERE id_area = 4";
			$stmt5 = $pdo->query($query5);
			$resultado5 = $stmt5->fetch(PDO::FETCH_ASSOC);
			
			// Contar todos los proyectos CYBER
			$query6 = "SELECT COUNT(*) AS bio FROM MDP_proyecto WHERE id_area = 1";
			$stmt6 = $pdo->query($query6);
			$resultado6 = $stmt6->fetch(PDO::FETCH_ASSOC);
			
			// Contar todos los proyectos NANO
			$query7 = "SELECT COUNT(*) AS nano FROM MDP_proyecto WHERE id_area = 2";
			$stmt7 = $pdo->query($query7);
			$resultado7 = $stmt7->fetch(PDO::FETCH_ASSOC);
			
			// Contar todos los proyectos NEXUS
			$query8 = "SELECT COUNT(*) AS nexus FROM MDP_proyecto WHERE id_area = 3";
			$stmt8 = $pdo->query($query8);
			$resultado8 = $stmt8->fetch(PDO::FETCH_ASSOC);
			
			//*******************************************
			// Contar todos los proyectos CONCEPTO
			$query9 = "SELECT COUNT(*) AS concepto FROM MDP_proyecto WHERE id_evaluacion = 1";
			$stmt9 = $pdo->query($query9);
			$resultado9 = $stmt9->fetch(PDO::FETCH_ASSOC);
			
			// Contar todos los proyectos PROTOTIPO
			$query10 = "SELECT COUNT(*) AS prototipo FROM MDP_proyecto WHERE id_evaluacion = 2";
			$stmt10 = $pdo->query($query10);
			$resultado10 = $stmt10->fetch(PDO::FETCH_ASSOC);
			
			// Contar todos los proyectos TERMINADOS
			$query11 = "SELECT COUNT(*) AS terminados FROM MDP_proyecto WHERE id_evaluacion = 3";
			$stmt11 = $pdo->query($query11);
			$resultado11 = $stmt11->fetch(PDO::FETCH_ASSOC);
			
			//*********************************************
		
		//Proyectos CYBER-CONCEPTO
		$query12 = "SELECT nombre FROM MDP_Orden_calificacion WHERE id_area = 4 AND id_evaluacion = 1 ORDER BY promedio DESC LIMIT 3";
		$stmt12 = $pdo->query($query12);
		$resultados12 = $stmt12->fetchAll();

		$primer_valorCC = $resultados12[0]['nombre'];
		$segundo_valorCC = $resultados12[1]['nombre'];
		$tercer_valorCC = $resultados12[2]['nombre'];
		
		//Proyectos CYBER-ALTA RESOLUCIÓN
		$query13 = "SELECT nombre FROM MDP_Orden_calificacion WHERE id_area = 4 AND id_evaluacion = 2 ORDER BY promedio DESC LIMIT 3";
		$stmt13 = $pdo->query($query13);
		$resultados13 = $stmt13->fetchAll();

		$primer_valorCA = $resultados13[0]['nombre'];
		$segundo_valorCA = $resultados13[1]['nombre'];
		$tercer_valorCA = $resultados13[2]['nombre'];
		
		//Proyectos CYBER-TERMINADO
		$query14 = "SELECT nombre FROM MDP_Orden_calificacion WHERE id_area = 4 AND id_evaluacion = 3 ORDER BY promedio DESC LIMIT 3";
		$stmt14 = $pdo->query($query14);
		$resultados14 = $stmt14->fetchAll();

		$primer_valorCT = $resultados14[0]['nombre'];
		$segundo_valorCT = $resultados14[1]['nombre'];
		$tercer_valorCT = $resultados14[2]['nombre'];
		
		//Proyectos NANO-CONCEPTO
		$query15 = "SELECT nombre FROM MDP_Orden_calificacion WHERE id_area = 2 AND id_evaluacion = 1 ORDER BY promedio DESC LIMIT 3";
		$stmt15 = $pdo->query($query15);
		$resultados15 = $stmt15->fetchAll();

		$primer_valorNAC = $resultados15[0]['nombre'];
		$segundo_valorNAC = $resultados15[1]['nombre'];
		$tercer_valorNAC = $resultados15[2]['nombre'];
		
		//Proyectos NANO-ALTA RESOLUCIÓN
		$query16 = "SELECT nombre FROM MDP_Orden_calificacion WHERE id_area = 2 AND id_evaluacion = 2 ORDER BY promedio DESC LIMIT 3";
		$stmt16 = $pdo->query($query16);
		$resultados16 = $stmt16->fetchAll();

		$primer_valorNAA = $resultados16[0]['nombre'];
		$segundo_valorNAA = $resultados16[1]['nombre'];
		$tercer_valorNAA = $resultados16[2]['nombre'];
		
		//Proyectos NANO-TERMINADO
		$query17 = "SELECT nombre FROM MDP_Orden_calificacion WHERE id_area = 2 AND id_evaluacion = 3 ORDER BY promedio DESC LIMIT 3";
		$stmt17 = $pdo->query($query17);
		$resultados17 = $stmt17->fetchAll();

		$primer_valorNAT = $resultados17[0]['nombre'];
		$segundo_valorNAT = $resultados17[1]['nombre'];
		$tercer_valorNAT = $resultados17[2]['nombre'];
		
		//Proyectos BIO-CONCEPTO
		$query18 = "SELECT nombre FROM MDP_Orden_calificacion WHERE id_area = 1 AND id_evaluacion = 1 ORDER BY promedio DESC LIMIT 3";
		$stmt18 = $pdo->query($query18);
		$resultados18 = $stmt18->fetchAll();

		$primer_valorBC = $resultados18[0]['nombre'];
		$segundo_valorBC = $resultados18[1]['nombre'];
		$tercer_valorBC = $resultados18[2]['nombre'];
		
		//Proyectos BIO-ALTA RESOLUCION
		$query19 = "SELECT nombre FROM MDP_Orden_calificacion WHERE id_area = 1 AND id_evaluacion = 2 ORDER BY promedio DESC LIMIT 3";
		$stmt19 = $pdo->query($query19);
		$resultados19 = $stmt19->fetchAll();

		$primer_valorBA = $resultados19[0]['nombre'];
		$segundo_valorBA = $resultados19[1]['nombre'];
		$tercer_valorBA = $resultados19[2]['nombre'];
		
		//Proyectos BIO-TERMINADO
		$query20 = "SELECT nombre FROM MDP_Orden_calificacion WHERE id_area = 1 AND id_evaluacion = 3 ORDER BY promedio DESC LIMIT 3";
		$stmt20 = $pdo->query($query20);
		$resultados20 = $stmt20->fetchAll();

		$primer_valorBT = $resultados20[0]['nombre'];
		$segundo_valorBT = $resultados20[1]['nombre'];
		$tercer_valorBT = $resultados20[2]['nombre'];
		
		//Proyectos NEXUS-CONCEPTO
		$query21 = "SELECT nombre FROM MDP_Orden_calificacion WHERE id_area = 3 AND id_evaluacion = 1 ORDER BY promedio DESC LIMIT 3";
		$stmt21 = $pdo->query($query21);
		$resultados21 = $stmt21->fetchAll();

		$primer_valorNEC = $resultados21[0]['nombre'];
		$segundo_valorNEC = $resultados21[1]['nombre'];
		$tercer_valorNEC = $resultados21[2]['nombre'];
		
		//Proyectos NEXUS-ALTA RESOLUCION
		$query22 = "SELECT nombre FROM MDP_Orden_calificacion WHERE id_area = 3 AND id_evaluacion = 2 ORDER BY promedio DESC LIMIT 3";
		$stmt22 = $pdo->query($query22);
		$resultados22 = $stmt22->fetchAll();

		$primer_valorNEA = $resultados22[0]['nombre'];
		$segundo_valorNEA = $resultados22[1]['nombre'];
		$tercer_valorNEA = $resultados22[2]['nombre'];
		
		//Proyectos NEXUS-TERMINADO
		$query23 = "SELECT nombre FROM MDP_Orden_calificacion WHERE id_area = 3 AND id_evaluacion = 3 ORDER BY promedio DESC LIMIT 3";
		$stmt23 = $pdo->query($query23);
		$resultados23 = $stmt23->fetchAll();

		$primer_valorNET = $resultados23[0]['nombre'];
		$segundo_valorNET = $resultados23[1]['nombre'];
		$tercer_valorNET = $resultados23[2]['nombre'];


	Database::disconnect();
		?> 
		
		
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8)>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie-edge">
	<title>Proyectos Actuales</title>
	<link rel="shortcut icon" href="/TC2005B_403_1/CRUD1/images/l2.jpg" type="image/x-icon">
	<link rel="stylesheet" href="/TC2005B_403_1/CRUD1/css/estilos10.css">
</head>

<body>
		
	<header>
    <table class="barra">
        <tr>
            <td> <img src="/TC2005B_403_1/CRUD1/images/expo1.jpg" alt="" class="logo"> </td>
            <td class="Inicio">
                <ul class="menu">
                    <li><a href="index.php">Inicio</a></li>
                </ul>
            </td>
            <td>
                <ul class="actual">
                    <li><a href="ProyectosActuales.php">Proyectos Actuales</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="Historial.php">Historial</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="jurados.php">Jurados</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="estudiantes.php">Estudiantes</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="asignacion.php">Asignacion</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="ediciones.php">Edicion</a></li>
                </ul>
            </td>
        </tr>
    </table>
</header>
		
		
		
	<section>
		<div class="proyectos">
			<h1>PROYECTOS</h1>
		</div>
		
		<table class="contador">
			<tr>
				<td class="letra">Registrados</td>
				<td class="letra">Pendientes</td>
				<td class="letra">Autorizados</td>
				<td class="letra">Rechazados</td>
			</tr>
			<tr>
				<td><?php echo $resultado['total']?></td>
				<td><?php echo $resultado2['pendientes']?></td>
				<td><?php echo $resultado3['autorizados']?></td>
				<td><?php echo $resultado4['rechazados']?></td>
			</tr>
		</table>
		
		<div align="center">
			<hr class="linea">
		</div>
		
		<table class="cate">
			<tr>
				<td colspan=4 class="letra">Área</td>
			</tr>
			<tr>
				<td class="letra">Cyber</td>
				<td class="letra">Nano</td>
				<td class="letra">Bio</td>
				<td class="letra">Nexus</td>
			</tr>
			<tr>
				<td><?php echo $resultado5['cyber']?></td>
				<td><?php echo $resultado7['nano']?></td>
				<td><?php echo $resultado6['bio']?></td>
				<td><?php echo $resultado8['nexus']?></td>
			</tr>
		</table>
		
		<div align="center">
			<hr class="linea">
		</div>
		
		<table class="cate">
			<tr>
				<td colspan=4 class="letra">Categoría Evaluación</td>
			</tr>
			<tr>
				<td class="letra">Concepto</td>
				<td class="letra">Prototipo de Baja Resolución</td>
				<td class="letra">Producto terminado</td>
			</tr>
			<tr>
				<td><?php echo $resultado9['concepto']?></td>
				<td><?php echo $resultado10['prototipo']?></td>
				<td><?php echo $resultado11['terminados']?></td>
			</tr>
		</table>
		
		<div align="center">
			<hr class="linea">
		</div>
		
		<table class="cate">
			<tr>
				<td colspan=4 class="letra">GANADORES</td>
			</tr>
			<tr>
				<td class="letra">Cyber</td>
				<td class="letra">Nano</td>
				<td class="letra">Bio</td>
				<td class="letra">Nexus</td>
			</tr>
			<tr>
				<th>Concepto</th>
				<th>Concepto</th>
				<th>Concepto</th>
				<th>Concepto</th>
			</tr>
			<tr>
				<td>1. <?php echo $primer_valorCC ?> </td>
				<td>1. <?php echo $primer_valorNAC ?> </td>
				<td>1. <?php echo $primer_valorBC ?></td>
				<td>1. <?php echo $primer_valorNEC ?></td>
			</tr>
			<tr>
				<td>2. <?php echo $segundo_valorCC ?></td>
				<td>2. <?php echo $segundo_valorNAC ?> </td>
				<td>2. <?php echo $segundo_valorBC ?></td>
				<td>2. <?php echo $segundo_valorNEC ?></td>
			</tr>
			<tr>
				<td>3. <?php echo $tercer_valorCC ?> </td>
				<td>3. <?php echo $tercer_valorNAC ?> </td>
				<td>3. <?php echo $tercer_valorBC ?></td>
				<td>3. <?php echo $tercer_valorNEC ?></td>
			</tr>
			<tr>
				<th>Baja Resolución</th>
				<th>Baja Resolución</th>
				<th>Baja Resolución</th>
				<th>Baja Resolución</th>
			</tr>
			<tr>
				<td>1. <?php echo $primer_valorCA ?></td>
				<td>1. <?php echo $primer_valorNAA ?></td>
				<td>1. <?php echo $primer_valorBA ?></td>
				<td>1. <?php echo $primer_valorNEA ?></td>
			</tr>
			<tr>
				<td>2. <?php echo $segundo_valorCA ?></td>
				<td>2. <?php echo $segundo_valorNAA ?></td>
				<td>2. <?php echo $segundo_valorBA ?></td>
				<td>2. <?php echo $segundo_valorNEA ?></td>
			</tr>
			<tr>
				<td>3. <?php echo $tercer_valorCA ?></td>
				<td>3. <?php echo $tercer_valorNAA ?></td>
				<td>3. <?php echo $tercer_valorBA ?></td>
				<td>3. <?php echo $tercer_valorNEA ?></td>
			</tr>
			<tr>
				<th>Producto Terminado</th>
				<th>Producto Terminado</th>
				<th>Producto Terminado</th>
				<th>Producto Terminado</th>
			</tr>
			<tr>
				<td>1. <?php echo $primer_valorCT ?></td>
				<td>1. <?php echo $primer_valorNAT ?></td>
				<td>1. <?php echo $primer_valorBT ?></td>
				<td>1. <?php echo $primer_valorNET ?></td>
			</tr>
			<tr>
				<td>2. <?php echo $segundo_valorCT ?></td>
				<td>2. <?php echo $segundo_valorNAT ?></td>
				<td>2. <?php echo $segundo_valorBT ?></td>
				<td>2. <?php echo $segundo_valorNET ?></td>
			</tr>
			<tr>
				<td>3. <?php echo $tercer_valorCT ?></td>
				<td>3. <?php echo $tercer_valorNAT ?></td>
				<td>3. <?php echo $tercer_valorBT ?></td>
				<td>3. <?php echo $tercer_valorNET ?></td>
			</tr>
		</table>
		
		
	</section>
	
	<div class="tabla">
		<table class="tabla1">
			<tr>
				<th>ID</th>
				<th>Nombre</th>
				<th>Profesor a cargo</th>
				<th>Calificación</th>
				<th>Área</th>
				<th>Evaluación</th>
				<th>Estatus</th>
			</tr>
			
			<?php
			
		   	foreach ($pdo->query($sql) as $row) {
				echo '<tr>';
				    	echo '<td>'. $row['id'] . '</td>';	    					 			
				    	echo '<td>'. $row['nombre'] . '</td>';
			                echo '<td>'. $row['profesor']." ".$row['apellidos'].'</td>';
			                echo '<td>'. $row['promedio'] . '</td>';	    
			                echo '<td>'. $row['categoria'] . '</td>';	    				
			                echo '<td>'. $row['evaluacion'] . '</td>';	    				
			                				
			                echo '<td>'. $row['estatus'] . '</td>';	
				echo '</tr>';
							    }
		   	
		?>  				
		</table>
	</div>
		
	<aside>
	</aside>
	
	<footer>
	</footer>

</body>
</html>
