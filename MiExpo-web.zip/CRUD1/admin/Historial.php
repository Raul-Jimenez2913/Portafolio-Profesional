<?php
			include 'database.php';
			$pdo = Database::connect();
		   	$sql = 'SELECT MDP_proyecto.*, 
		   	MDP_estatus.nombre AS estatus, 
		   	MDP_categoria_area.nombre AS categoria, 
		   	MDP_categoria_evaluacion.nombre AS evaluacion, 
		   	MDP_Orden_calificacion.promedio, 
		   	MDP_profesor.nombre AS profesor, 
		   	MDP_profesor.apellidos AS apellidos, 
		   	MDP_proyecto.Id_unidad_formacion AS uf, 
		   	MDP_proyecto.id_edicion as periodo,
		   	MDP_alumno.matricula as participantes,
		   	MDP_jurado_proyecto.id_jurado as jurado 
		   	FROM MDP_proyecto 
		   	INNER JOIN MDP_estatus ON MDP_proyecto.id_estatus = MDP_estatus.id 
		   	INNER JOIN MDP_categoria_area ON MDP_proyecto.id_area = MDP_categoria_area.id 
		   	INNER JOIN MDP_profesor ON MDP_proyecto.id_profesor = MDP_profesor.nomina 
		   	INNER JOIN MDP_categoria_evaluacion ON MDP_proyecto.id_evaluacion = MDP_categoria_evaluacion.id
		   	INNER JOIN MDP_alumno_proyecto ON MDP_proyecto.id = MDP_alumno_proyecto.id_proyecto
		   	INNER JOIN MDP_alumno ON MDP_alumno_proyecto.matricula = MDP_alumno.matricula
		   	INNER JOIN MDP_jurado_proyecto ON MDP_proyecto.id = MDP_jurado_proyecto.id_proyecto
		   	INNER JOIN MDP_jurado ON MDP_jurado_proyecto.id_jurado = MDP_jurado.id
		   	INNER JOIN MDP_Orden_calificacion ON MDP_proyecto.id = MDP_Orden_calificacion.id';

			  
  
	Database::disconnect();
		?> 
		
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8)>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie-edge">
	<title>Historial</title>
	<link rel="shortcut icon" href="/TC2005B_403_1/CRUD1/images/l2.jpg" type="image/x-icon">
	<link rel="stylesheet" href="/TC2005B_403_1/CRUD1/css/estilos11.css">
</head>

<body>
		
	<header>
    <table class="barra">
        <tr>
            <td> <img src="/TC2005B_403_1/CRUD1/images/expo1.jpg" alt="" class="logo"> </td>
            <td class="Inicio">
                <ul class="menu">
                    <li><a href="index.php">Inicio</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="ProyectosActuales.php">Proyectos Actuales</a></li>
                </ul>
            </td>
            <td>
                <ul class="actual">
                    <li><a href="Historial.php">Historial</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="jurados.php">Jurados</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="estudiantes.php">Estudiantes</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="asignacion.php">Asignacion</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="ediciones.php">Edicion</a></li>
                </ul>
            </td>
        </tr>
    </table>
</header>
		
		
		
	<section>
		<div class="proyectos">
			<h1>HISTORIAL</h1>
		</div>
		

	</section>
	
	<div class="tabla">
		<table class="tabla1">
			<tr>
				<th>ID</th>
				<th>Nombre</th>
				<th>Matrículas equipo</th>
				<th>Calificación</th>
				<th>Profesor</th>
				<th>ID jurados</th>
				<th>Estatus</th>
				<th>Área</th>
				<th>Evaluación</th>
				<th>UF</th>
				<th>Periodo</th>
			</tr>
			
			<?php
			
		   	foreach ($pdo->query($sql) as $row) {
				echo '<tr>';
				    	echo '<td>'. $row['id'] . '</td>';	    					 			
				    	echo '<td>'. $row['nombre'] . '</td>';
			                echo '<td>'. $row['participantes'] . '</td>';
			                echo '<td>'. $row['promedio'].'</td>';
			                echo '<td>'. $row['profesor']." ".$row['apellidos'].'</td>';	    				
			                echo '<td>'. $row['jurado'] . '</td>';
			                echo '<td>'. $row['estatus'] . '</td>';		    
			                echo '<td>'. $row['categoria'] . '</td>';	    				
			                echo '<td>'. $row['evaluacion'] . '</td>';	    				
			                				
			                echo '<td>'. $row['uf'] . '</td>';
			                echo '<td>'. $row['periodo'] . '</td>';	   
				echo '</tr>';
							    }
		   	
		?>  	
		</table>
	</div>
	
		<div class="registrar" align="right">
			<a href="create_excel.php"><input type="button" value="Descargar" class="guardar"> </a>
		</div>

</body>
</html>
