<?php

	require 'database.php';

	$id = null;
	if ( !empty($_GET['id'])) {
		$id = $_REQUEST['id'];
	}

	if ( $id==null ) {
		header("Location: asignacion.php");
	}

	if ( !empty($_POST)) {
		$idError   = null;
		$nomError  = null;
		$vidError  = null;
		$posError  = null;
		$imgError  = null;
		$catError  = null;
		$evError   = null;
		$profError = null;
		$ufError   = null;
		
		// keep track post values
		$id   = $_POST['id'];
		$nom  = $_POST['nom'];
		$vid  = $_POST['vid'];
		$pos  = $_POST['pos'];
		$img  = $_POST['img'];
		$cat  = $_POST['cat'];
		$ev   = $_POST['ev'];
		$prof = $_POST['prof'];
		$uf   = $_POST['uf'];
		
		
		/// validate input
		$valid = true;

		if (empty($nom)) {
			$nomError = 'Porfavor escribe una submarca';
			$valid = false;
		}

		if (empty($vid)) {
			$vidError = 'Porfavor escribe el enlace del video';
			$valid = false;
		}
		
		if (empty($pos)) {
			$posError = 'Porfavor escribe el enlace del poster';
			$valid = false;
		}
		if (empty($img)) {
			$imgError = 'Porfavor escribe el enlace de la imagen';
			$valid = false;
		}
		if (empty($cat)) {
			$catError = 'Porfavor selecciona una categoria';
			$valid = false;
		}
		if (empty($ev)) {
			$evError = 'Porfavor selecciona un nivel de desarrollo';
			$valid = false;
		}
		if (empty($prof)) {
			$profError = 'Porfavor escribe un profesor';
			$valid = false;
		}

		if (empty($uf)) {
			$ufError = 'Porfavor selecciona la unidad de formacion';
			$valid = false;
		}
		

		// update data
		if ($valid) {
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "UPDATE MDP_proyecto SET id = ?, nombre = ?, video = ?, poster = ?, imagen = ?, id_area = ?, id_evaluacion = ?, id_profesor = ?, Id_unidad_formacion = ? WHERE MDP_proyecto.id = ?";
			$q = $pdo->prepare($sql);
			$q->execute(array($id,$nom,$vid,$pos,$img,$cat,$ev,$prof,$uf,$id));
			//$sql = "UPDATE MDP_jurado_proyecto SET id = ?, nombre = ?, video = ?, poster = ?, imagen = ?, id_area = ?, id_evaluacion = ?, id_profesor = ?, Id_unidad_formacion = ? WHERE MDP_proyecto.id = ?";
			//$q = $pdo->prepare($sql);
			//$q->execute(array($id,$nom,$vid,$pos,$img,$cat,$ev,$prof,$uf,$id));
			Database::disconnect();
			header("Location: asignacion.php");
		}
	}
	else {
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM MDP_proyecto WHERE id = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$data= $q->fetch(PDO::FETCH_ASSOC);
		$id  = $data['id'];
		$nom = $data['nombre'];
		$prof= $data['id_profesor'];
		$cat = $data['id_area'];
		$ev  = $data['id_evaluacion'];
		$uf  = $data['Id_unidad_formacion'];
		$vid = $data['video'];
		$pos = $data['poster'];
		$img = $data['imagen'];
		Database::disconnect();
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>EditarProyecto </title>
		<link rel="shortcut icon" href="/TC2005B_403_1/CRUD1/images/l2.jpg" type="image/x-icon">
		<link rel="stylesheet" type"text/css" href="/TC2005B_403_1/CRUD1/css/estilos2.css">
		<script src="/TC2005B_403_1/CRUD1/js/script2.js"></script>
	</head>
	
	<body>
		
		<header>
    <table class="barra">
        <tr>
            <td> <img src="/TC2005B_403_1/CRUD1/images/expo1.jpg" alt="" class="logo"> </td>
            <td class="Inicio">
                <ul class="menu">
                    <li><a href="index.php">Inicio</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="ProyectosActuales.php">Proyectos Actuales</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="Historial.php">Historial</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="jurados.php">Jurados</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="estudiantes.php">Estudiantes</a></li>
                </ul>
            </td>
            <td>
                <ul class="actual">
                    <li><a href="asignacion.php">Asignacion</a></li>
                </ul>
            </td>
            <td>
                <ul class="menu">
                    <li><a href="ediciones.php">Edicion</a></li>
                </ul>
            </td>
        </tr>
    </table>
</header>
		
			<section class="textos-header">
				<h1> Editar Poyecto </h1>
				<h1> Id: <?php echo $data['id'];?> </h1>
			</section>
			<div class="wave" style="height: 150px; overflow: hidden;" ><svg viewBox="0 0 500 150" preserveAspectRatio="none" style="height: 100%; width: 100%;"><path d="M0.00,49.98 C282.44,51.81 294.86,50.83 500.00,49.98 L500.00,150.00 L0.00,150.00 Z" style="stroke: none; fill: #fff;"></path></svg></div>
		</header>
		
		
		<div class="contenedor">
			<form class="form-horizontal" action="EditarProyectoAdmin.php?id=<?php echo $id?>" method="post">
					<table class="tabla">
						<tr>
							<td rowspan=10><img src= <?php echo $data['imagen'];?> alt="" class="imagen_gokart"></td>
						</tr>
						<tr>
							<td>Id:</td>
							<td>
							<div class="control-group <?php echo !empty($idError)?'error':'';?>">
							<div class="controls">
					      	<input name="id" type="text" readonly placeholder="id" value="<?php echo !empty($id)?$id:''; ?>">
					      	<?php if (!empty($idError)): ?>
					      		<span class="help-inline"><?php echo $idError;?></span>
					      	<?php endif; ?>
					    </div>
						</div>
						</td>
						</tr>
						<tr>
							<td>Nombre del proyecto:</td>
							<td>	
							<div class="control-group <?php echo !empty($nomError)?'error':'';?>">
							<div class="controls">
					      	<input name="nom" type="text" placeholder="nombre" value="<?php echo !empty($nom)?$nom:'';?>">
					      	<?php if (!empty($nomError)): ?>
					      		<span class="help-inline"><?php echo $nomError;?></span>
					      	<?php endif;?>
							</div>
							</div>
							</td>
						</tr>
						<tr>
							<td>Docente:</td>
							<td> 
							<div class="control-group <?php echo !empty($profError)?'error':'';?>">
							<div class="controls">
							<select name ="prof">
		                        <option value="">Selecciona un docente</option>
		                        <?php
							   		$pdo = Database::connect();
							   		$query = 'SELECT *,CONCAT(nombre," ",apellidos) AS nombre_completo FROM MDP_profesor';
			 				   		foreach ($pdo->query($query) as $row) {
		                        		if ($row['nomina']==$prof)
		                        			echo "<option selected value='" . $row['nomina'] . "'>" . $row['nombre_completo'] . "</option>";
		                        		else
		                        			echo "<option value='" . $row['nomina'] . "'>" . $row['nombre_completo'] . "</option>";
			   						}
			   						Database::disconnect();
			  					?>
                            </select>
					      	<?php if (!empty($profError)): ?>
					      		<span class="help-inline"><?php echo $profError;?></span>
					      	<?php endif;?>
							</div>
							</div>
							</td>
						</tr>
						<tr>
							<td>Área estratégica:</td>
							<td> 
							<div class="control-group <?php echo !empty($catError)?'error':'';?>">
							<div class="controls">
							<select name ="cat">
		                        <option value="<?php echo !empty($cat)?$cat:''; ?>">Selecciona un área</option>
		                        <?php
							   		$pdo = Database::connect();
							   		$query = 'SELECT * FROM MDP_categoria_area';
			 				   		foreach ($pdo->query($query) as $row) {
		                        		if ($row['id']==$cat)
		                        			echo "<option selected value='" . $row['id'] . "'>" . $row['nombre'] . "</option>";
		                        		else
		                        			echo "<option value='" . $row['id'] . "'>" . $row['nombre'] . "</option>";
			   						}
			   						Database::disconnect();
			  					?>
                            </select>
					      	<?php if (!empty($catError)): ?>
					      		<span class="help-inline"><?php echo $catError;?></span>
					      	<?php endif;?>
							</div>
							</div>
							</td>
						</tr>
						<tr>
							<td>Enlace video:</td>
							<td>
							<div class="control-group <?php echo !empty($vidError)?'error':'';?>">
							<div class="controls">
					      	<input name="vid" type="text" placeholder="video" value="<?php echo !empty($vid)?$vid:'';?>">
					      	<?php if (!empty($vidError)): ?>
					      		<span class="help-inline"><?php echo $nomError;?></span>
					      	<?php endif;?>
							</div>
							</div>
							</td>
						</tr>

						<tr>
							<td>Enlace poster:</td>
							<td>	
							<div class="control-group <?php echo !empty($posError)?'error':'';?>">
							<div class="controls">
					      	<input name="pos" type="text" placeholder="poster" value="<?php echo !empty($pos)?$pos:'';?>">
					      	<?php if (!empty($posError)): ?>
					      		<span class="help-inline"><?php echo $posError;?></span>
					      	<?php endif;?>
							</div>
							</div>
							</td>
						</tr>
						<tr>
							<td>Enlace imagen:</td>
							<td>	
							<div class="control-group <?php echo !empty($imgError)?'error':'';?>">
							<div class="controls">
					      	<input name="img" type="text" placeholder="img" value="<?php echo !empty($img)?$img:'';?>">
					      	<?php if (!empty($imgError)): ?>
					      		<span class="help-inline"><?php echo $imgError;?></span>
					      	<?php endif;?>
							</div>
							</div>
							</td>
						</tr>
						<tr>
							<td>Unidad de formación:</td>
							<td> 
							<div class="control-group <?php echo !empty($ufError)?'error':'';?>">
							<div class="controls">
							<select name ="uf">
		                        <option value="<?php echo !empty($uf)?$uf:''; ?>">Selecciona una UF</option>
		                        <?php
							   		$pdo = Database::connect();
							   		$query = 'SELECT * FROM MDP_unidad_formacion';
			 				   		foreach ($pdo->query($query) as $row) {
		                        		if ($row['clave']==$uf)
		                        			echo "<option selected value='" . $row['clave'] . "'>" . $row['nombre'] . "</option>";
		                        		else
		                        			echo "<option value='" . $row['clave'] . "'>" . $row['nombre'] . "</option>";
			   						}
			   						Database::disconnect();
			  					?>
                            </select>
					      	<?php if (!empty($ufError)): ?>
					      		<span class="help-inline"><?php echo $ufError;?></span>
					      	<?php endif;?>
							</div>
							</div>
							</td>
						</tr>
						<tr>
							<td>Nivel de desarrollo:</td>
							<td> 
							<div class="control-group <?php echo !empty($evError)?'error':'';?>">
							<div class="controls">
							<select name ="ev">
		                        <option value="<?php echo !empty($ev)?$ev:''; ?>">Selecciona un nivel</option>
		                        <?php
							   		$pdo = Database::connect();
							   		$query = 'SELECT * FROM MDP_categoria_evaluacion';
			 				   		foreach ($pdo->query($query) as $row) {
		                        		if ($row['id']==$ev)
		                        			echo "<option selected value='" . $row['id'] . "'>" . $row['nombre'] . "</option>";
		                        		else
		                        			echo "<option value='" . $row['id'] . "'>" . $row['nombre'] . "</option>";
			   						}
			   						Database::disconnect();
			  					?>
                            </select>
					      	<?php if (!empty($evError)): ?>
					      		<span class="help-inline"><?php echo $evError;?></span>
					      	<?php endif;?>
							</div>
							</div>
							</td>
						</tr>
							<td>
								<a href=<?php echo '"verAdmin.php?id='.$data['id'].'"'; ?>><input type="button" value="Volver" class="guardar" align="right"/></a>
								<button type="submit" class="guardar">Actualizar</button>
							</td>
						</tr>
					</table>
					

			</form>
		</div>
				
	</body>
	
	<footer class="text-center footer-style">
		
		<p class="tec">D.R. INSTITUTO TECNOLÓGICO Y DE ESTUDIOS SUPERIORES DE MONTERREY 2023</p>
		
	</footer>
	
</html>
