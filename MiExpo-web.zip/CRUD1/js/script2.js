function myFunction(){
	window.alert("Proyecto Registrado con éxito. De clic en aceptar");
}

function exitoso(){
	window.alert("Registro exitoso. De clic en aceptar");
}

function myFunction1(){
	window.alert("Proyecto Editado con éxito. De clic en aceptar");
}

function alerta()
    {
    var opcion = confirm("¿Cerrar sesión?");
    if (opcion == true) {
        window.location.href="file:///C:/Users/jacqu/Documents/pagina/index.html";
	} else {
	    window.location.href="file:///C:/Users/jacqu/Documents/pagina/iniciada.html";
	}
}

function alertaAdmin()
    {
    var opcion = confirm("¿Cerrar sesión?");
    if (opcion == true) {
        window.location.href="file:///C:/Users/jacqu/Documents/pagina/index.html";
	} else {
	    window.location.href="file:///C:/Users/jacqu/Documents/pagina/iniciadaAdmin.html";
	}
}

function alertaExterno()
    {
    var opcion = confirm("¿Cerrar sesión?");
    if (opcion == true) {
        window.location.href="file:///C:/Users/jacqu/Documents/pagina/index.html";
	} else {
	    window.location.href="file:///C:/Users/jacqu/Documents/pagina/iniciadaExterno.html";
	}
}

function alertaProfe()
    {
    var opcion = confirm("¿Cerrar sesión?");
    if (opcion == true) {
        window.location.href="file:///C:/Users/jacqu/Documents/pagina/index.html";
	} else {
	    window.location.href="file:///C:/Users/jacqu/Documents/pagina/iniciadaProfe.html";
	}
}
