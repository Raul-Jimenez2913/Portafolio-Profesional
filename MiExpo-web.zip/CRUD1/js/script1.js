function myFunction(){
	window.location.href="file:///C:/Users/jacqu/Documents/pagina/verProfesor.html";
	window.alert("Proyecto autorizado con éxito. De clic en aceptar");
}

function calificar(){
	window.alert("Proyecto calificado con éxito. De clic en aceptar");
}
