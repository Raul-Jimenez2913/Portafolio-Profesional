<?php
    session_start();
    require 'database.php';
	
	$sql = 'SELECT MDP_extras.* FROM MDP_extras WHERE id=1';
        $i = 0;
        
    $correoError = $passwordError = $loginError = '';
    $correo = $password = '';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // validate input
        $valid = true;
        if (empty($_POST['correo'])) {
            $correoError = 'Por favor ingrese su correo electrónico';
            $valid = false;
        } else {
            $correo = $_POST['correo'];
        }

        if (empty($_POST['password'])) {
            $passwordError = 'Por favor ingrese su contraseña';
            $valid = false;
        } else {
            $password = $_POST['password'];
        }
	
        // check login credentials in MDP_alumno
        if ($valid) {
            $pdo = Database::connect();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "SELECT * FROM MDP_alumno WHERE correo = ? AND password = ?";
            $q = $pdo->prepare($sql);
            $q->execute(array($correo, $password));
            $data = $q->fetch(PDO::FETCH_ASSOC);
            if ($data) {
				$matricula = $data['matricula'];
				$_SESSION['matricula'] = $matricula;
				header("Location: /TC2005B_403_1/CRUD1/EstudianteP/index.php");
			} else {
                // check login credentials in MDP_profesor
                $sql = "SELECT * FROM MDP_profesor WHERE correo = ? AND password = ?";
                $q = $pdo->prepare($sql);
                $q->execute(array($correo, $password));
                $data = $q->fetch(PDO::FETCH_ASSOC);
                if ($data) {
					$nomina = $data['nomina'];
                    $_SESSION['nomina'] = $nomina;
				$_SESSION['correo'] = $correo;
				$_SESSION['password'] = $password;
                    header("Location: /TC2005B_403_1/CRUD1/profesor/index.php");
                } else {
                    // check login credentials in MDP_jurado
                    $sql = "SELECT * FROM MDP_jurado WHERE correo = ? AND password = ?";
                    $q = $pdo->prepare($sql);
                    $q->execute(array($correo, $password));
                    $data = $q->fetch(PDO::FETCH_ASSOC);
                    if ($data) {
						$ide = $data['id'];
                        $_SESSION['id'] = $ide;
                        header("Location: /TC2005B_403_1/CRUD1/juez/index.php");
                    } else {
                     $sql = "SELECT * FROM MDP_administrador WHERE correo = ? AND password = ?";
                    $q = $pdo->prepare($sql);
                    $q->execute(array($correo, $password));
                    $data = $q->fetch(PDO::FETCH_ASSOC);
                    if ($data) {
						
                        header("Location: /TC2005B_403_1/CRUD1/admin/index.php");
                    } else {
                        $loginError = 'Correo o contraseña incorrectos';
                    }
                    }
                }
            }
            Database::disconnect();
        }
    }
?>

    
   <?php
		$pdo = Database::connect();
		$query = 'SELECT anuncio AS anuncio FROM MDP_extras';
		foreach ($pdo->query($query) as $row) {
		if ($row['id']==$prof)
		"<option selected value='" . $row['id'] . "'>" . $row['anuncio'] . "</option>";
		 else
		"<option value='" . $row['id'] . "'>" . $row['anuncio'] . "</option>";
		
		$frase = $row['anuncio'];
		$subcadena = substr($frase, 32, 33); 
		}
	Database::disconnect();
   ?>
   
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Inicio </title>
		<link rel="shortcut icon" href="images/l2.jpg" type="image/x-icon">
		<link rel="stylesheet" type="text/css" href="css/estilos6.css">
	</head>
	
	<body>
		
		<header>
		<table class="barra">
			<tr>
				<td> <img src="images/expo1.jpg" alt="" class="logo"> </td>
				<td class="Inicio">
					<ul class="menu">
						<li><a href="index.php">Inicio</a></li>
					</ul>
				</td>
			</tr>
		</table>
			
			<section class="textos-header">
			<table class="NUEVO">
				<tr>
				<td>
					<div class="rectangulo1">
					<h1> Regístrate </h1>
				
					<div class="usuario">
						<a href= "RegistroEstudiante.php"><input type="button" value="Estudiante" class="alumno"></a>
						<a href= "RegistroProfesor.php"><input type="button" value="Docente" class="profesor"></a>
						<a href= "RegistroJuez.php"><input type="button" value="Externo" class="juez"></a>
					</div>
			   
					<div class="sesion">
						<h4>¿Ya tienes una cuenta?</h4>
						<p>Inicia Sesión</p>
					</div>
					
					<div class="iniciar">
						 <form method="post" action="index.php">

						<table class="tabla">
							<tr>
								<td>Email</td>
								<td><input type="text" name="correo" id="correo" value="<?php echo !empty($correo) ? $correo : ''; ?>">
                                <?php if (!empty($correoError)): ?>
                                <span><?php echo $correoError; ?></span>
                                <?php endif; ?></td>
							</tr>
							<tr>
								<td>Contraseña</td>
								<td><input type="password" name="password" id="password">
                                <?php if (!empty($passwordError)): ?>
                                    <span><?php echo $passwordError; ?></span>
                                <?php endif; ?></td>
							</tr>
							<tr>
								
								<td colspan="2">	
								<button type="submit">Iniciar sesión</button>
								<?php if (!empty($loginError)): ?>
								<span><?php echo $loginError; ?></span>
								<?php endif; ?>

								</form>
                            </tr>
						</table>
					</div>
			   </div>
				</td>
					<td>
						<div class="anuncios">
							<img src=<?php echo "https://drive.google.com/uc?export=view&id=".$subcadena;?>  alt="" class="anuncio">
						</div>
					</td>
				</tr>
				
				</table>
				
			</section>
			<div class="wave" style="height: 150px; overflow: hidden;" ><svg viewBox="0 0 500 150" preserveAspectRatio="none" style="height: 100%; width: 100%;"><path d="M0.00,49.98 C282.44,51.81 294.86,50.83 500.00,49.98 L500.00,150.00 L0.00,150.00 Z" style="stroke: none; fill: #fff;"></path></svg></div>
			
		</header>
			
			<table class="info">
				<tr>
					<td><h3>En la Escuela de Ingeniería y Ciencias del Tec de Monterrey estamos convencidos de que el ingenio humano es lo que transforma al mundo.</h3><br>
					<p>En este evento podrás conocer muestras y exhibiciones de los proyectos más ingeniosos, innovadores y peculiares de estudiantes actuales de todas nuestras carreras de Ingeniería y Ciencias. También podrás participar en diversas actividades interactivas como las que se describen a continuación.</p></td>
					<td><iframe width="560" height="315" src="https://www.youtube.com/embed/E1fUpr9EA-Y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></td>
					
				</tr>
			</table>
			
		<div class="contenedor">
			
		</div>	
	
	</body>

	<footer class="text-center footer-style">
		
		<p class="siguenos">Síguenos</p>
		
		<hr width=400>
		
		<table class="redes">
			<tr>/
				<td> <img src="images/twitter.png" alt="" class="twitter"> </td>
				<td> <img src="images/instagram.png" alt="" class="instagram"> </td>
				<td> <img src="images/facebook.png" alt="" class="facebook"> </td>
				<td> <img src="images/youtube.png" alt="" class="youtube"> </td>
			</tr>
		</table>
		
		<p class="tec">D.R. INSTITUTO TECNOLÓGICO Y DE ESTUDIOS SUPERIORES DE MONTERREY 2023</p>
		
	</footer>

	
</html>
