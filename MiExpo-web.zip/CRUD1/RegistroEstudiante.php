<?php


	require 'database.php';

		$matError = null;
		$nomError = null;
		$apeError = null;
		$corrError= null;
		$conError = null;
		$fecError = null;
		$carrError= null;


	if ( !empty($_POST)) {

		$mat = $_POST['mat'];
		$nom = $_POST['nom'];
		$ape   = $_POST['ape'];
		$corr   = $_POST['corr'];
		$con   = $_POST['con'];
		$fec   = $_POST['fec'];
		$carr   = $_POST['carr'];



		// validate input
		$valid = true;

		if (empty($mat)) {
			$matError = 'Porfavor ingrese su matrícula';
			$valid = false;
		}
		if (empty($nom)) {
			$nomError = 'Porfavor escriba su nombre';
			$valid = false;
		}
		if (empty($ape)) {
			$apeError = 'Porfavor escriba sus apellidos';
			$valid = false;
		}
		if (empty($corr)) {
			$corrError = 'Porfavor ingrese su correo institucional';
			$valid = false;
		}
		if (empty($con)) {
			$conError = 'Porfavor ingrese una contraseña';
			$valid = false;
		}
		if (empty($fec)) {
			$fecError = 'Porfavor ingrese su fecha de ingreso';
			$valid = false;
		}
		if (empty($carr)) {
			$carrError = 'Porfavor ingrese las siglas de su carrera';
			$valid = false;
		}
		
		
		// insert data
		if ($valid) {
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "INSERT INTO MDP_alumno (matricula,nombre,apellidos,correo,password,fecha_ingreso,id_carrera) values(?, ?, ?, ?, ?, ?, ?)";
			$q = $pdo->prepare($sql);
			$q->execute(array($mat,$nom,$ape,$corr,$con,$fec,$carr));
			Database::disconnect();
			header("Location: /TC2005B_403_1/CRUD1/exitoso.php");
			Database::disconnect();

		}
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>RegistroEstudiante </title>
		<link rel="shortcut icon" href="/TC2005B_403_1/CRUD1/images/l2.jpg" type="image/x-icon">
		<link rel="stylesheet" type="text/css" href="/TC2005B_403_1/CRUD1/css/style.css">
		<link rel="stylesheet" type"text/css" href="/TC2005B_403_1/CRUD1/css/estilos7.css">
		<script src="/TC2005B_403_1/CRUD1/js/script2.js"></script>
	</head>
	
	<body>
		
		<header>
		<header>
		<table class="barra">
			<tr>
				<td> <img src="/TC2005B_403_1/CRUD1/images/expo1.jpg" alt="" class="logo"> </td>
				<td class="Inicio">
					<ul class="menu">
						<li><a href="index.php">Inicio</a></li>
					</ul>
				</td>
			</tr>
		</table>
		
			<section class="textos-header">
				<h1> Registro Estudiante </h1>
			</section>
			<div class="wave" style="height: 250px; overflow: hidden;" ><svg viewBox="0 0 500 150" preserveAspectRatio="none" style="height: 150%; width: 100%;"><path d="M0.00,49.98 C282.44,51.81 294.86,50.83 500.00,49.98 L500.00,150.00 L0.00,150.00 Z" style="stroke: none; fill: #fff;"></path></svg></div>
		</header>
		
<form method="post" action="RegistroEstudiante.php">
		<div class="contenedor">
		
			<table class="tabla">
				<tr>
					<td>
					<div class="control-group <?php echo !empty($matError)?'error':'';?>">
						<label class="control-label">Matrícula:</label>
					    <div class="controls">
					    <td>
					      	<input name="mat" type="text"  placeholder="Matrícula" value="<?php echo !empty($mat)?$mat:'';?>">
					      	<?php if (($matError != null)) ?>
					      		<span class="help-inline"><?php echo $matError;?></span>
					    </td>
					    </div>
					</div>
					</td>
				</tr>
				<tr>
					<td>
					<div class="control-group <?php echo !empty($nomError)?'error':'';?>">
						<label class="control-label">Nombre:</label>
					    <div class="controls">
					    <td>
					      	<input name="nom" type="text"  placeholder="Nombre" value="<?php echo !empty($nom)?$nom:'';?>">
					      	<?php if (($nomError != null)) ?>
					      		<span class="help-inline"><?php echo $nomError;?></span>
					    </td>
					    </div>
					</div>
					</td>
				</tr>
				<tr>
					<td>
						<div class="control-group <?php echo !empty($apeError)?'error':'';?>">
						<label class="control-label">Apellidos:</label>
					    <div class="controls">
					    <td>
					      	<input name="ape" type="text"  placeholder="Apellidos" value="<?php echo !empty($ape)?$ape:'';?>">
					      	<?php if (($apeError != null)) ?>
					      		<span class="help-inline"><?php echo $apeError;?></span>
					    </td>
					    </div>
						</div>
					</td>
				</tr>
				<tr>
					<td>
						<div class="control-group <?php echo !empty($corrError)?'error':'';?>">
						<label class="control-label">Correo Institucional:</label>
					    <div class="controls">
					    <td>
					      	<input name="corr" type="email"  placeholder="Correo" value="<?php echo !empty($corr)?$corr:'';?>">
					      	<?php if (($corrError != null)) ?>
					      		<span class="help-inline"><?php echo $corrError;?></span>
					    </td>
					    </div>
						</div>
					</td>
				</tr>
				<tr>
					<td>
						<div class="control-group <?php echo !empty($fecError)?'error':'';?>">
						<label class="control-label">Fecha de ingreso:</label>
					    <div class="controls">
					    <td>
					      	<input name="fec" type="date"  placeholder="Fecha" value="<?php echo !empty($fec)?$fec:'';?>">
					      	<?php if (($fecError != null)) ?>
					      		<span class="help-inline"><?php echo $fecError;?></span>
					    </td>
					    </div>
						</div>
					</td>
				</tr>
				<tr>
					<td>
						<div class="control-group <?php echo !empty($carrError)?'error':'';?>">
						<label class="control-label">Carrera:</label>
				    	<div class="controls">
				    	<td>
	                       	<select name ="carr">
		                        <option value="">Selecciona una Carrera:</option>
		                        <?php
							   		$pdo = Database::connect();
							   		$query = 'SELECT * FROM MDP_carrera';
			 				   		foreach ($pdo->query($query) as $row) {
		                        		if ($row['id_carrera']==$carr)
		                        			echo "<option selected value='" . $row['id_carrera'] . "'>" . $row['nombre'] . "</option>";
		                        		else
		                        			echo "<option value='" . $row['id_carrera'] . "'>" . $row['nombre'] . "</option>";
			   						}
			   						Database::disconnect();
			  					?>
                            </select>
					      	<?php if (($carrError) != null) ?>
					      		<span class="help-inline"><?php echo $carrError;?></span>
						</div>
					</div>
					</td>
				</tr>
				<tr>
					<td>
						<div class="control-group <?php echo !empty($conError)?'error':'';?>">
						<label class="control-label">Contraseña:</label>
					    <div class="controls">
					    <td>
					      	<input name="con" type="password"  placeholder="Contraseña" value="<?php echo !empty($con)?$con:'';?>">
					      	<?php if (($conError != null)) ?>
					      		<span class="help-inline"><?php echo $conError;?></span>
					    </td>
					    </div>
						</div>
					</td>
				</tr>
			</table>
		</div>
		
		<div class="registrar" align="right">
			<div class="input-group">
			<a href="index.php"><input type="button" value="Volver" class="guardar" align="right"/></a>
  	  <button type="submit" class="guardar" name="reg_user">Registrarse</button>
  	</div>
		</div>	
	</form>
	</body>
	
	<footer class="text-center footer-style">
		
		<p class="tec">D.R. INSTITUTO TECNOLÓGICO Y DE ESTUDIOS SUPERIORES DE MONTERREY 2023</p>
		
	</footer>
	
</html>
