<?php
session_start(); // Inicia la sesión

	// Asigna el valor de la variable de sesión a la variable matricula
	$nomina = $_SESSION['nomina'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8)>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie-edge">
	<title>MisProyectos</title>
	<link rel="shortcut icon" href="/TC2005B_403_1/CRUD1/images/l2.jpg" type="image/x-icon">
	<link rel="stylesheet" href="/TC2005B_403_1/CRUD1/css/estilos26.css">
</head>

<body>

	<header>
		<table class="barra">
			<tr>
				<td> <img src="/TC2005B_403_1/CRUD1/images/expo1.jpg" alt="" class="logo"> </td>
				<td class="Inicio">
					<ul class="menu">
						<li><a href="index.php">Inicio</a></li>
					</ul>
				</td>
				<td>
					<ul class="actual">
						<?php echo '<li><a href="verProfesor.php?nomina=' . $nomina . '">Mis Proyectos</a></li>'; ?>
					</ul>
				</td>
				<td>
					<ul class="menu">
						<li><a href="mapa.php">Proyectos</a></li>
					</ul>
				</td>
			</tr>
		</table>
		
	</header>
		
	<section>
			
			<h1 align="left" class="h1"> Proyectos Pendientes </h1>
			<table class="proyectos">
				   <?php
        include 'database.php';
        $pdo = Database::connect();
        
        if ( !empty($_GET['nomina'])) {
    $nomina = $_GET['nomina'];
} else {
    header("Location: index.php");
}

    if ($nomina == null) {
        header("Location: index.php");
    }
    
    
        $sql = 'SELECT MDP_proyecto.*, MDP_estatus.nombre AS estatus FROM MDP_proyecto INNER JOIN MDP_estatus ON MDP_proyecto.id_estatus = MDP_estatus.id INNER JOIN MDP_profesor ON MDP_proyecto.id_profesor = MDP_profesor.nomina WHERE MDP_estatus.nombre = "Pendiente" AND MDP_profesor.nomina = ?;';
        $stmt = $pdo->prepare($sql);
$stmt->execute([$nomina]);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
   $i = 0;
        foreach ($results as $row) {
            if ($i % 2 == 0) { // Si el contador es par, empieza una nueva fila
                echo '<tr>';
            }
            echo '<td>';
            $frase = $row['imagen'];
	    $subcadena = substr($frase, 32, 33); 
            echo '<img src="https://drive.google.com/uc?export=view&id='.$subcadena.'" alt="" class="imagen_router" height = 250>';
            echo '<a href="ProyectosProfesor.php?id='.$row['id'].'"><h4>'.$row['nombre'].'</h4></a>';
            
            //$estatusClass = ($row['estatus'] == "Autorizado") ? "aproved" : ($row['estatus'] == "Pendiente") ? "pendient" : "rechazado";
            $estatusClass = ($row['estatus'] == "Autorizado") ? "aproved" : "pendient";
            
            echo '<p class='.$estatusClass.'>'.$row['estatus'].'</p>';
            $estatusClass = "";
            echo '</td>';
            if ($i % 2 != 0) { // Si el contador es impar, cierra la fila
                echo '</tr>';
            }
            $i++;
        }
        if ($i % 2 != 0) { // Si el último elemento dejó una fila abierta, ciérrala
            echo '</tr>';
        }
        Database::disconnect();
    ?>
			</table>
			
			<h1 align="left" class="h12"> Proyectos Autorizados </h1>
			<table class="proyectos">
				<?php
        $pdo = Database::connect();
        
        if ( !empty($_GET['nomina'])) {
    $nomina = $_GET['nomina'];
} else {
    header("Location: index.php");
}

    if ($nomina == null) {
        header("Location: index.php");
    }
    
        $sql = 'SELECT MDP_proyecto.*, MDP_estatus.nombre AS estatus FROM MDP_proyecto INNER JOIN MDP_estatus ON MDP_proyecto.id_estatus = MDP_estatus.id INNER JOIN MDP_profesor ON MDP_proyecto.id_profesor = MDP_profesor.nomina WHERE MDP_estatus.nombre = "Autorizado" AND MDP_profesor.nomina = ?';
        $stmt = $pdo->prepare($sql);
$stmt->execute([$nomina]);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
   $i = 0;
        foreach ($results as $row) {
            if ($i % 2 == 0) { // Si el contador es par, empieza una nueva fila
                echo '<tr>';
            }
            echo '<td>';
            $frase = $row['imagen'];
	    $subcadena = substr($frase, 32, 33); 
            echo '<img src="https://drive.google.com/uc?export=view&id='.$subcadena.'" alt="" class="imagen_router" height = 250>';
            echo '<a href="ProyectosProfesor.php?id='.$row['id'].'"><h4>'.$row['nombre'].'</h4></a>';
            
            //$estatusClass = ($row['estatus'] == "Autorizado") ? "aproved" : ($row['estatus'] == "Pendiente") ? "pendient" : "rechazado";
            $estatusClass = ($row['estatus'] == "Autorizado") ? "aproved" : "pendient";
            
            echo '<p class='.$estatusClass.'>'.$row['estatus'].'</p>';
            $estatusClass = "";
            echo '</td>';
            if ($i % 2 != 0) { // Si el contador es impar, cierra la fila
                echo '</tr>';
            }
            $i++;
        }
        if ($i % 2 != 0) { // Si el último elemento dejó una fila abierta, ciérrala
            echo '</tr>';
        }
        Database::disconnect();
    ?>
			</table>	
	</section>

</body>

	<footer class="text-center footer-style">
		
		<p class="tec">D.R. INSTITUTO TECNOLÓGICO Y DE ESTUDIOS SUPERIORES DE MONTERREY 2023</p>
		
	</footer>
	
</html>
