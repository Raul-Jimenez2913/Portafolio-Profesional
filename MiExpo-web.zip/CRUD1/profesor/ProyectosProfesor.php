<?php
session_start(); // Inicia la sesión

	// Asigna el valor de la variable de sesión a la variable matricula
	$nomina = $_SESSION['nomina'];
	
	require 'database.php';
	$id = null;
	if ( !empty($_GET['id'])) {
		$id = $_REQUEST['id'];
	}
	if ( $id==null) {
		header("Location: index.php");
	} else {
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT MDP_proyecto.*, MDP_estatus.nombre AS estatus, 
		MDP_categoria_area.nombre AS categoria, MDP_categoria_evaluacion.nombre AS evaluacion, MDP_profesor.nombre AS profesor, MDP_unidad_formacion.clave AS uf,
		MDP_profesor.apellidos AS apellidos, MDP_Orden_calificacion.promedio,
		GROUP_CONCAT(CONCAT(MDP_alumno.matricula, ' ', MDP_alumno.nombre, ' ', MDP_alumno.apellidos) SEPARATOR '<br>') AS participantes
		FROM MDP_proyecto 
		INNER JOIN MDP_estatus ON MDP_proyecto.id_estatus = MDP_estatus.id 
		INNER JOIN MDP_categoria_area ON MDP_proyecto.id_area = MDP_categoria_area.id
		INNER JOIN MDP_categoria_evaluacion ON MDP_proyecto.id_evaluacion = MDP_categoria_evaluacion.id 
		INNER JOIN MDP_unidad_formacion ON MDP_proyecto.Id_unidad_formacion = MDP_unidad_formacion.clave
		INNER JOIN MDP_profesor ON MDP_proyecto.id_profesor = MDP_profesor.nomina
		LEFT JOIN MDP_Orden_calificacion ON MDP_proyecto.id = MDP_Orden_calificacion.id
		INNER JOIN MDP_alumno_proyecto ON MDP_proyecto.id = MDP_alumno_proyecto.id_proyecto
		INNER JOIN MDP_alumno ON MDP_alumno_proyecto.matricula = MDP_alumno.matricula
		WHERE MDP_proyecto.id = ?
		GROUP BY MDP_proyecto.id;";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$data = $q->fetch(PDO::FETCH_ASSOC);
		
		$frase = $data['imagen'];
		$subcadena = substr($frase, 32, 33); 
		//echo $subcadena;
		if ($data['estatus'] == "Autorizado") {
  		  $clase = "aproved";
		} 
		
		if ($data['estatus'] == "Pendiente") {
  		  $clase = "pendient";
		}
		Database::disconnect();
	}
	
	if ( !empty($_POST)) {
		// keep track post values
		$id = $_POST['id'];
		// update data
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "UPDATE MDP_proyecto SET id_estatus = 2 WHERE id = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		Database::disconnect();
		header("Location: /TC2005B_403_1/CRUD1/profesor/verProfesor.php");
	}
?>


<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8)>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie-edge">
	<title>VerProyecto</title>
	<link rel="shortcut icon" href="/TC2005B_403_1/CRUD1/images/l2.jpg" type="image/x-icon">
	<link rel="stylesheet" href="/TC2005B_403_1/CRUD1/css/estilos5.css">
	<script src="/TC2005B_403_1/CRUD1/js/script1.js"></script>
</head>

<body>

	<header>
		<table class="barra">
			<tr>
				<td> <img src="/TC2005B_403_1/CRUD1/images/expo1.jpg" alt="" class="logo"> </td>
				<td class="Inicio">
					<ul class="menu">
						<li><a href="index.php">Inicio</a></li>
					</ul>
				</td>
				<td>
					<ul class="actual">
						<li><a href="verProfesor.php">Mis Proyectos</a></li>
					</ul>
				</td>
				<td>
					<ul class="menu">
						<li><a href="mapa.php">Proyectos</a></li>
					</ul>
				</td>
			</tr>
		</table>
	</header>
		
		
		
	<section>
	
		<table class="proyectos">
			<tr>
				<td> <p class= <?php echo $clase;?>> <?php echo $data['estatus'];?> </p> <h4 class="pro"><?php echo $data['nombre'];?></h4></td>
				<td rowspan=2><p class="id">ID: <?php echo $data['id'];?></p><br><img src=<?php echo "https://drive.google.com/uc?export=view&id=".$subcadena;?> alt="" class="imagen_gokart"> </td>
			</tr>
			
			<tr>
				<td rowspan=2 class="descripcion"> <h4 class="cat"> Categoría Área: <br><p class = "data" > <?php echo $data['categoria'];?></p> <br>
				
				Categoría Evaluación: <br><p class = "data" > <?php echo $data['evaluacion'];?></p><br>
				
				Unidad de Formación: <br><p class = "data" > <?php echo $data['uf'];?></p>
				
				
				</h4> 
				</td>
			</tr>
			
			<tr>
				<td><a href=<?php echo $data['video'];?> target="_blank" ><input type="button" value="Video" class="multimedia"></a><br><br>
				<a href=<?php echo $data['poster'];?>  target="_blank"><input type="button" value="Poster" class="multimedia"></a></td>
			</tr>
			
			<tr>
				<td class="profe">Profesor a cargo<br> <p class = "data" > <?php echo $data['profesor']. " ". $data['apellidos'];?> </p></td>
				<td class="cali">Calificacion: <?php echo $data['promedio'];?> / 4</td>
			</tr>
			
			<tr>
				<td colspan=2 class="parti"> Participantes <br> <?php echo $data['participantes']; ?> </td>
			</tr>
		
		</table>
		
	
	</section>
	
		
		
	<aside align="right">
		<a href="verProfesor.php?nomina=<?php echo $nomina ?>"> <input type="button" value="Volver" class="aprobar1" align="right"> </a>
		
		<form class="form-horizontal" action="ProyectosProfesor.php" method="post">
		    		<input type="hidden" name="id" value="<?php echo $id;?>"/>
					<div class="form-actions">
						<button type="submit" class="aprobar" onclick="myFunction()">Autorizar</button>
					</div>
		</form>
		
		
	</aside>

</body>

	<footer class="text-center footer-style">
		
		<p class="tec">D.R. INSTITUTO TECNOLÓGICO Y DE ESTUDIOS SUPERIORES DE MONTERREY 2023</p>
		
	</footer>
	
</html>
