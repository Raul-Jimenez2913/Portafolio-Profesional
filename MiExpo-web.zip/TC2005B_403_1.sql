-- MySQL dump 10.13  Distrib 8.0.32, for Linux (x86_64)
--
-- Host: localhost    Database: TC2005B_403_1
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.22.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `MDP_Autorizados`
--

DROP TABLE IF EXISTS `MDP_Autorizados`;
/*!50001 DROP VIEW IF EXISTS `MDP_Autorizados`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `MDP_Autorizados` AS SELECT 
 1 AS `id`,
 1 AS `nombre`,
 1 AS `video`,
 1 AS `poster`,
 1 AS `id_area`,
 1 AS `id_evaluacion`,
 1 AS `id_profesor`,
 1 AS `id_edicion`,
 1 AS `id_unidad_formacion`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `MDP_Autorizados_NoAutorizados`
--

DROP TABLE IF EXISTS `MDP_Autorizados_NoAutorizados`;
/*!50001 DROP VIEW IF EXISTS `MDP_Autorizados_NoAutorizados`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `MDP_Autorizados_NoAutorizados` AS SELECT 
 1 AS `id`,
 1 AS `nombre`,
 1 AS `video`,
 1 AS `poster`,
 1 AS `id_area`,
 1 AS `id_evaluacion`,
 1 AS `id_profesor`,
 1 AS `id_edicion`,
 1 AS `id_unidad_formacion`,
 1 AS `estatus`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `MDP_Orden_calificacion`
--

DROP TABLE IF EXISTS `MDP_Orden_calificacion`;
/*!50001 DROP VIEW IF EXISTS `MDP_Orden_calificacion`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `MDP_Orden_calificacion` AS SELECT 
 1 AS `id`,
 1 AS `nombre`,
 1 AS `video`,
 1 AS `poster`,
 1 AS `id_area`,
 1 AS `id_evaluacion`,
 1 AS `id_profesor`,
 1 AS `id_edicion`,
 1 AS `id_unidad_formacion`,
 1 AS `promedio`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `MDP_administrador`
--

DROP TABLE IF EXISTS `MDP_administrador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MDP_administrador` (
  `id` int NOT NULL AUTO_INCREMENT,
  `correo` varchar(30) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDP_administrador`
--

LOCK TABLES `MDP_administrador` WRITE;
/*!40000 ALTER TABLE `MDP_administrador` DISABLE KEYS */;
INSERT INTO `MDP_administrador` VALUES (1,'rafaexpoing@gmail.com','miexpo24*');
/*!40000 ALTER TABLE `MDP_administrador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MDP_alumno`
--

DROP TABLE IF EXISTS `MDP_alumno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MDP_alumno` (
  `matricula` varchar(10) NOT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  `apellidos` varchar(30) DEFAULT NULL,
  `correo` varchar(30) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `fecha_ingreso` date DEFAULT NULL,
  `id_carrera` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`matricula`),
  KEY `id_carrera` (`id_carrera`),
  CONSTRAINT `MDP_alumno_ibfk_1` FOREIGN KEY (`id_carrera`) REFERENCES `MDP_carrera` (`id_carrera`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDP_alumno`
--

LOCK TABLES `MDP_alumno` WRITE;
/*!40000 ALTER TABLE `MDP_alumno` DISABLE KEYS */;
INSERT INTO `MDP_alumno` VALUES ('A0145223','Oscar','Perez','A0145223@tec.mx','asfsf8*','2023-05-03','IMT'),('A01700356','Carlos','Santos','a01700356@tec.mx','gtr345','2019-08-24','IMT'),('A01701478','Karla','Oróstico','a01701478@tec.mx','rosaroja651','2019-08-24','IBT'),('A01727445','María','Sánchez','a01727445@tec.mx','ajolote3000','2020-08-24','IRS'),('A01736302','Christian','Jimenez','A01736302@tec.mx','12345','2021-07-07','IMT'),('A01736339','Juan','Neruda','a01736339@tec.mx','guayaba85','2021-08-24','ITC'),('A01736345','Luis Angel','Cruz','A01736345@tec.mx','12345','2021-08-17','ITC'),('A01736893','Alan','Cruz','A01736893@tec.mx','787878','2021-06-22','IRS'),('A01784215','Enrique','Hernández','a01784215@tec.mx','gokuInstinto20','2021-08-24','ITC');
/*!40000 ALTER TABLE `MDP_alumno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MDP_alumno_proyecto`
--

DROP TABLE IF EXISTS `MDP_alumno_proyecto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MDP_alumno_proyecto` (
  `matricula` varchar(10) NOT NULL,
  `id_proyecto` int NOT NULL,
  `id_rol` int DEFAULT NULL,
  PRIMARY KEY (`matricula`,`id_proyecto`),
  KEY `id_proyecto` (`id_proyecto`),
  KEY `id_rol` (`id_rol`),
  CONSTRAINT `MDP_alumno_proyecto_ibfk_1` FOREIGN KEY (`matricula`) REFERENCES `MDP_alumno` (`matricula`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `MDP_alumno_proyecto_ibfk_2` FOREIGN KEY (`id_proyecto`) REFERENCES `MDP_proyecto` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `MDP_alumno_proyecto_ibfk_3` FOREIGN KEY (`id_rol`) REFERENCES `MDP_rol` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDP_alumno_proyecto`
--

LOCK TABLES `MDP_alumno_proyecto` WRITE;
/*!40000 ALTER TABLE `MDP_alumno_proyecto` DISABLE KEYS */;
INSERT INTO `MDP_alumno_proyecto` VALUES ('A01700356',1,1),('A01701478',2,1),('A01727445',3,1),('A01736302',10,1),('A01736339',4,1),('A01736345',9,1),('A01736345',11,1),('A0145223',9,2),('A0145223',10,2),('A0145223',11,2),('A01700356',9,2),('A01700356',10,2),('A01700356',11,2),('A01784215',4,2);
/*!40000 ALTER TABLE `MDP_alumno_proyecto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MDP_carrera`
--

DROP TABLE IF EXISTS `MDP_carrera`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MDP_carrera` (
  `id_carrera` varchar(3) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_carrera`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDP_carrera`
--

LOCK TABLES `MDP_carrera` WRITE;
/*!40000 ALTER TABLE `MDP_carrera` DISABLE KEYS */;
INSERT INTO `MDP_carrera` VALUES ('IBT','Ingeniería en Biotecnología'),('IMT','Ingeniería en Mecatrónica'),('IRS','Ingeniería en Robótica y Sistemas Digitales'),('ITC','Ingeniería en Tecnologías Computacionales');
/*!40000 ALTER TABLE `MDP_carrera` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MDP_categoria_area`
--

DROP TABLE IF EXISTS `MDP_categoria_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MDP_categoria_area` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDP_categoria_area`
--

LOCK TABLES `MDP_categoria_area` WRITE;
/*!40000 ALTER TABLE `MDP_categoria_area` DISABLE KEYS */;
INSERT INTO `MDP_categoria_area` VALUES (1,'Bio'),(2,'Nano'),(3,'Nexus'),(4,'Cyber');
/*!40000 ALTER TABLE `MDP_categoria_area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MDP_categoria_evaluacion`
--

DROP TABLE IF EXISTS `MDP_categoria_evaluacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MDP_categoria_evaluacion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDP_categoria_evaluacion`
--

LOCK TABLES `MDP_categoria_evaluacion` WRITE;
/*!40000 ALTER TABLE `MDP_categoria_evaluacion` DISABLE KEYS */;
INSERT INTO `MDP_categoria_evaluacion` VALUES (1,'Concepto'),(2,'Prototipo de baja resolución'),(3,'Producto terminado');
/*!40000 ALTER TABLE `MDP_categoria_evaluacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MDP_edicion`
--

DROP TABLE IF EXISTS `MDP_edicion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MDP_edicion` (
  `id` varchar(5) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDP_edicion`
--

LOCK TABLES `MDP_edicion` WRITE;
/*!40000 ALTER TABLE `MDP_edicion` DISABLE KEYS */;
INSERT INTO `MDP_edicion` VALUES ('FJ 23','Febrero-Junio 2023');
/*!40000 ALTER TABLE `MDP_edicion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MDP_estatus`
--

DROP TABLE IF EXISTS `MDP_estatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MDP_estatus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDP_estatus`
--

LOCK TABLES `MDP_estatus` WRITE;
/*!40000 ALTER TABLE `MDP_estatus` DISABLE KEYS */;
INSERT INTO `MDP_estatus` VALUES (1,'Pendiente'),(2,'Autorizado'),(3,'No autorizado');
/*!40000 ALTER TABLE `MDP_estatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MDP_extras`
--

DROP TABLE IF EXISTS `MDP_extras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MDP_extras` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mapa` varchar(250) DEFAULT NULL,
  `anuncio` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDP_extras`
--

LOCK TABLES `MDP_extras` WRITE;
/*!40000 ALTER TABLE `MDP_extras` DISABLE KEYS */;
INSERT INTO `MDP_extras` VALUES (1,'https://drive.google.com/file/d/1mnfBiHgB7fDxZZM3D17r5kgtLawqXWzg/view?usp=sharing','https://drive.google.com/file/d/1OVFfE8LVgvFY6VKRQ9Lhc6hTr_tsUty3/view?usp=sharing');
/*!40000 ALTER TABLE `MDP_extras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MDP_jurado`
--

DROP TABLE IF EXISTS `MDP_jurado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MDP_jurado` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) DEFAULT NULL,
  `apellidos` varchar(30) DEFAULT NULL,
  `correo` varchar(30) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `procedencia` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDP_jurado`
--

LOCK TABLES `MDP_jurado` WRITE;
/*!40000 ALTER TABLE `MDP_jurado` DISABLE KEYS */;
INSERT INTO `MDP_jurado` VALUES (1,'Elon','Musk','elonm@gmail.com','musk456','Tesla'),(2,'Jeffrey','Bezos','jefbe@gmail.com','bezos147','Amazon'),(3,'Claudia','Perez','perez.claudia@tec.mx','clps297','TEC PUE'),(4,'Aida','Salazar','aida.sc@tec.mx','scaida321','TEC PUE'),(5,'David','Torres','davidant@tec.mx','dmtr12','TEC PUE'),(6,'Julian','Yunes','jayunes@tec.mx','jadroy23','TEC PUE'),(7,'Alberto','Oliart','aoliart@tec.mx','mttalrt749','TEC PUE'),(8,'Rafael','Expo','rafag@tex.mx','ingenieria12*','TEC PUE'),(9,'Hugo','Ramirez','L011@tec.mx','123432','TEC PUE');
/*!40000 ALTER TABLE `MDP_jurado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MDP_jurado_proyecto`
--

DROP TABLE IF EXISTS `MDP_jurado_proyecto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MDP_jurado_proyecto` (
  `id_jurado` int NOT NULL,
  `id_proyecto` int NOT NULL,
  `calificacion` int DEFAULT NULL,
  `comentario` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id_jurado`,`id_proyecto`),
  KEY `id_proyecto` (`id_proyecto`),
  CONSTRAINT `MDP_jurado_proyecto_ibfk_1` FOREIGN KEY (`id_jurado`) REFERENCES `MDP_jurado` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `MDP_jurado_proyecto_ibfk_2` FOREIGN KEY (`id_proyecto`) REFERENCES `MDP_proyecto` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDP_jurado_proyecto`
--

LOCK TABLES `MDP_jurado_proyecto` WRITE;
/*!40000 ALTER TABLE `MDP_jurado_proyecto` DISABLE KEYS */;
INSERT INTO `MDP_jurado_proyecto` VALUES (1,1,3,'Buen trabajo'),(2,4,4,NULL),(2,8,NULL,NULL),(3,3,4,NULL),(3,4,NULL,NULL),(4,2,2,NULL),(4,3,NULL,NULL),(5,3,3,NULL),(6,2,3,NULL),(7,4,4,NULL),(8,8,NULL,NULL);
/*!40000 ALTER TABLE `MDP_jurado_proyecto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MDP_profesor`
--

DROP TABLE IF EXISTS `MDP_profesor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MDP_profesor` (
  `nomina` varchar(10) NOT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  `apellidos` varchar(30) DEFAULT NULL,
  `correo` varchar(30) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`nomina`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDP_profesor`
--

LOCK TABLES `MDP_profesor` WRITE;
/*!40000 ALTER TABLE `MDP_profesor` DISABLE KEYS */;
INSERT INTO `MDP_profesor` VALUES ('L01','Daniel','Perez','danperez@tec.mx','danP123'),('L011','Hugo','Ramirez','L011@tec.mx','123432'),('L02','Aida','Salazar','aida.sc@tec.mx','scaida321'),('L03','Gibran','Sayeg','gsayeg@tec.mx','gisateg987'),('L04','Hera','Andrade','handradez@tec.mx','hsald3');
/*!40000 ALTER TABLE `MDP_profesor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MDP_proyecto`
--

DROP TABLE IF EXISTS `MDP_proyecto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MDP_proyecto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  `video` varchar(200) DEFAULT NULL,
  `poster` varchar(200) DEFAULT NULL,
  `id_area` int DEFAULT NULL,
  `id_evaluacion` int DEFAULT NULL,
  `id_profesor` varchar(10) DEFAULT NULL,
  `id_estatus` int DEFAULT NULL,
  `id_edicion` varchar(5) DEFAULT NULL,
  `Id_unidad_formacion` varchar(10) DEFAULT NULL,
  `imagen` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_area` (`id_area`),
  KEY `id_evaluacion` (`id_evaluacion`),
  KEY `id_profesor` (`id_profesor`),
  KEY `id_estatus` (`id_estatus`),
  KEY `id_edicion` (`id_edicion`),
  KEY `Id_unidad_formacion` (`Id_unidad_formacion`),
  CONSTRAINT `MDP_proyecto_ibfk_1` FOREIGN KEY (`id_area`) REFERENCES `MDP_categoria_area` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `MDP_proyecto_ibfk_2` FOREIGN KEY (`id_evaluacion`) REFERENCES `MDP_categoria_evaluacion` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `MDP_proyecto_ibfk_3` FOREIGN KEY (`id_profesor`) REFERENCES `MDP_profesor` (`nomina`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `MDP_proyecto_ibfk_4` FOREIGN KEY (`id_estatus`) REFERENCES `MDP_estatus` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `MDP_proyecto_ibfk_5` FOREIGN KEY (`id_edicion`) REFERENCES `MDP_edicion` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `MDP_proyecto_ibfk_6` FOREIGN KEY (`Id_unidad_formacion`) REFERENCES `MDP_unidad_formacion` (`clave`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDP_proyecto`
--

LOCK TABLES `MDP_proyecto` WRITE;
/*!40000 ALTER TABLE `MDP_proyecto` DISABLE KEYS */;
INSERT INTO `MDP_proyecto` VALUES (1,'Go Kart','https://drive.google.com/file/d/14','https://lh3.googleusercontent.com/drive-viewer/AAOQEORrGQQ7RuprZVyqJ-nLm94Yg76U-p9y87Z9caYpEqxQyzue9SW11WUIHLBm4dPR5F5WvBi2GPutJuhXkqrIyFAS_ruynA=s2560',4,2,'L03',3,'FJ 23','MR2004B','https://drive.google.com/file/d/1lm6f6Iriqqiye-kGIT5VSa3Ah-Ba3I4U/view?usp=sharing'),(2,'Parque eolico','https://drive.google.com/file/d/10','https://lh3.googleusercontent.com/drive-viewer/AAOQEOStN17zeU8SS9vWT8NBfL2yYpwo9IwMhB4MCLe3yrLH2TJfT51EPgAqs4w8g_ecVdXMJRiSaEgJGaHKjFbRwtf6SAy1=s1600',3,1,'L04',2,'FJ 23','IB1006','https://drive.google.com/file/d/1yqqBDezcrKL2e62JY7QLy8AiAlHBsMAx/view?usp=sharing'),(3,'Drone autonomo','https://drive.google.com/file/d/15','https://lh3.googleusercontent.com/drive-viewer/AAOQEOQW0PzpGO2OR74p3Y76CWF41YaehA4TQDm80yCNhe9F0WsEOHzwuz6iijDPSI140MLiTZmjH-veF9NVz-ISBymlEoN8=s1600',4,3,'L01',2,'FJ 23','MR2004B','https://drive.google.com/file/d/19kZx-HMD3-6-vwjR8Jdxcuuif_YkzX20/view?usp=sharing'),(4,'Mini lenguaje2','https://drive.google.com/file/d/03','https://lh3.googleusercontent.com/drive-viewer/AAOQEORGQkJJOd_b-lHou-LNEHC6vMqbiu4nNopPEdvy09GzfYfTfzfBDiuAWzNvy4xwSiX-aWTsr7EYqZ5-xI1rlOngFu-L=s2560',4,2,'L03',2,'FJ 23','TC2037','https://drive.google.com/file/d/155DsNe6YaaDpqpMwZKGVquVplKGclhZz/view?usp=sharing'),(8,'prueba','https://drive.google.com/file/d/14','https://drive.google.com/file/d/14',1,1,'L01',1,'FJ 23','F1013B',NULL),(9,'Domotica ','www.y.com','www.drve.com',4,2,'L01',2,'FJ 23','F1013B','https://drive.google.com/file/d/1_0B6MDP_XstQTFDmJNXjJ3jJeT2Mi9CR/view?usp=sharing'),(10,'Programa ','www.y.com','www.drve.com',4,2,'L01',2,'FJ 23','MR2004B','https://drive.google.com/file/d/1eq6HGywh0CN24GpPg71ufW2GPph3C1Fc/view?usp=sharing'),(11,'Generador','www.y.com','www.drve.com',2,3,'L02',1,'FJ 23','TC1004B','https://drive.google.com/file/d/1XdH5UgsEOLEiDmN8puqcaHyUSnKUJTYq/view?usp=sharing');
/*!40000 ALTER TABLE `MDP_proyecto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MDP_rol`
--

DROP TABLE IF EXISTS `MDP_rol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MDP_rol` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDP_rol`
--

LOCK TABLES `MDP_rol` WRITE;
/*!40000 ALTER TABLE `MDP_rol` DISABLE KEYS */;
INSERT INTO `MDP_rol` VALUES (1,'Lider'),(2,'Participante');
/*!40000 ALTER TABLE `MDP_rol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MDP_unidad_formacion`
--

DROP TABLE IF EXISTS `MDP_unidad_formacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MDP_unidad_formacion` (
  `clave` varchar(10) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `semestre` int DEFAULT NULL,
  PRIMARY KEY (`clave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MDP_unidad_formacion`
--

LOCK TABLES `MDP_unidad_formacion` WRITE;
/*!40000 ALTER TABLE `MDP_unidad_formacion` DISABLE KEYS */;
INSERT INTO `MDP_unidad_formacion` VALUES ('F1013B','Modelación computacional de sistemas eléctricos',2),('IB1006','Biomimética y sustentabilidad',1),('MR2004B','Implementación de sistemas mecatrónicos',6),('TC1004B','Implementación de Internet de las cosas',3),('TC2037','Implementación de métodos computacionales',4);
/*!40000 ALTER TABLE `MDP_unidad_formacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alumno`
--

DROP TABLE IF EXISTS `alumno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alumno` (
  `matricula` varchar(10) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `apellidos` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alumno`
--

LOCK TABLES `alumno` WRITE;
/*!40000 ALTER TABLE `alumno` DISABLE KEYS */;
INSERT INTO `alumno` VALUES ('A01322222','Luis','Prince'),('A01322234','Juan','Diaz'),('A01327678','Ramón','Ramos'),('A01328765','David','Lopez'),('A01329876','Oscar','Rodriguez'),('A01329999','Francisco','Flores');
/*!40000 ALTER TABLE `alumno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alumnoGrupo`
--

DROP TABLE IF EXISTS `alumnoGrupo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alumnoGrupo` (
  `matricula` varchar(10) NOT NULL,
  `clave` varchar(10) NOT NULL,
  `calificacion` int DEFAULT NULL,
  PRIMARY KEY (`matricula`,`clave`),
  KEY `clave` (`clave`),
  CONSTRAINT `alumnoGrupo_ibfk_1` FOREIGN KEY (`matricula`) REFERENCES `alumno` (`matricula`) ON DELETE CASCADE,
  CONSTRAINT `alumnoGrupo_ibfk_2` FOREIGN KEY (`clave`) REFERENCES `grupo` (`clave`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alumnoGrupo`
--

LOCK TABLES `alumnoGrupo` WRITE;
/*!40000 ALTER TABLE `alumnoGrupo` DISABLE KEYS */;
INSERT INTO `alumnoGrupo` VALUES ('A01322222','G1',85),('A01322222','G10',NULL),('A01322222','G11',NULL),('A01322222','G12',NULL),('A01322222','G3',92),('A01322222','G4',NULL),('A01322222','G5',34),('A01322234','G1',90),('A01322234','G11',NULL),('A01322234','G12',NULL),('A01322234','G2',94),('A01322234','G4',NULL),('A01322234','G7',NULL),('A01322234','G9',87),('A01327678','G1',80),('A01327678','G11',NULL),('A01327678','G12',NULL),('A01327678','G3',95),('A01327678','G4',NULL),('A01327678','G6',92),('A01327678','G9',91),('A01328765','G1',99),('A01328765','G11',NULL),('A01328765','G12',NULL),('A01328765','G2',94),('A01328765','G4',NULL),('A01328765','G7',NULL),('A01328765','G9',89),('A01329876','G1',95),('A01329876','G11',NULL),('A01329876','G12',NULL),('A01329876','G3',92),('A01329876','G4',NULL),('A01329876','G5',93),('A01329876','G8',73),('A01329999','G1',92),('A01329999','G10',NULL),('A01329999','G11',NULL),('A01329999','G12',NULL),('A01329999','G2',99),('A01329999','G4',NULL),('A01329999','G5',99);
/*!40000 ALTER TABLE `alumnoGrupo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auto`
--

DROP TABLE IF EXISTS `auto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auto` (
  `idauto` int NOT NULL AUTO_INCREMENT,
  `nombrec` varchar(20) DEFAULT NULL,
  `idmarca` int DEFAULT NULL,
  `ac` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idauto`),
  KEY `idmarca` (`idmarca`),
  CONSTRAINT `auto2_ibfk_1` FOREIGN KEY (`idmarca`) REFERENCES `marca` (`idmarca`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auto`
--

LOCK TABLES `auto` WRITE;
/*!40000 ALTER TABLE `auto` DISABLE KEYS */;
INSERT INTO `auto` VALUES (3,'acord',1,0),(4,'polo',2,0);
/*!40000 ALTER TABLE `auto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grupo`
--

DROP TABLE IF EXISTS `grupo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `grupo` (
  `clave` varchar(10) NOT NULL,
  `id_p` int DEFAULT NULL,
  `nomina` varchar(10) DEFAULT NULL,
  `clave_u` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`clave`),
  KEY `id_p` (`id_p`),
  KEY `nomina` (`nomina`),
  KEY `clave_u` (`clave_u`),
  CONSTRAINT `grupo_ibfk_1` FOREIGN KEY (`id_p`) REFERENCES `periodo` (`id`) ON DELETE SET NULL,
  CONSTRAINT `grupo_ibfk_2` FOREIGN KEY (`nomina`) REFERENCES `profesor` (`nomina`) ON DELETE SET NULL,
  CONSTRAINT `grupo_ibfk_3` FOREIGN KEY (`clave_u`) REFERENCES `unidadFormacion` (`clave`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grupo`
--

LOCK TABLES `grupo` WRITE;
/*!40000 ALTER TABLE `grupo` DISABLE KEYS */;
INSERT INTO `grupo` VALUES ('G1',2,'L01','TC3001'),('G10',3,'L06','TC5004'),('G11',3,'L06','MT3006'),('G12',3,'L07','TC3003'),('G2',1,'L02','MT1004'),('G3',2,'L03','MT1004'),('G4',3,'L01','TC3002'),('G5',1,'L04','TC4003'),('G6',2,'L05','TC4003'),('G7',3,'L04','TC4003'),('G8',1,'L06','TC5004'),('G9',2,'L06','TC5004');
/*!40000 ALTER TABLE `grupo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marca`
--

DROP TABLE IF EXISTS `marca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marca` (
  `idmarca` int NOT NULL,
  `nombrem` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`idmarca`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marca`
--

LOCK TABLES `marca` WRITE;
/*!40000 ALTER TABLE `marca` DISABLE KEYS */;
INSERT INTO `marca` VALUES (1,'Honda'),(2,'Volkswagen'),(3,'Ford'),(4,'Susuki'),(5,'Mazda'),(6,'Acura');
/*!40000 ALTER TABLE `marca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `user_id` int NOT NULL,
  `amount` decimal(20,2) DEFAULT NULL,
  `ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `user_id` (`user_id`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,200.00,'2023-03-17 16:32:51');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `periodo`
--

DROP TABLE IF EXISTS `periodo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `periodo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `periodo`
--

LOCK TABLES `periodo` WRITE;
/*!40000 ALTER TABLE `periodo` DISABLE KEYS */;
INSERT INTO `periodo` VALUES (1,'EM19'),(2,'AD19'),(3,'FJ20');
/*!40000 ALTER TABLE `periodo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profesor`
--

DROP TABLE IF EXISTS `profesor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profesor` (
  `nomina` varchar(10) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `apellidos` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`nomina`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profesor`
--

LOCK TABLES `profesor` WRITE;
/*!40000 ALTER TABLE `profesor` DISABLE KEYS */;
INSERT INTO `profesor` VALUES ('L01','Daniel','Perez'),('L02','Aida','Salazar'),('L03','Gribran','Sayeg'),('L04','Claudia Verónica ','Perez'),('L05','Jose Alberto','Palomares'),('L06','Alberto','Oliart'),('L07','Sandra','Barajas');
/*!40000 ALTER TABLE `profesor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tr`
--

DROP TABLE IF EXISTS `tr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tr` (
  `id` int NOT NULL AUTO_INCREMENT,
  `recibe_id` int NOT NULL,
  `paga_id` int NOT NULL,
  `cantidad` decimal(20,2) DEFAULT NULL,
  `tr` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `recibe_id` (`recibe_id`),
  KEY `paga_id` (`paga_id`),
  CONSTRAINT `tr_ibfk_1` FOREIGN KEY (`recibe_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tr_ibfk_2` FOREIGN KEY (`paga_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tr`
--

LOCK TABLES `tr` WRITE;
/*!40000 ALTER TABLE `tr` DISABLE KEYS */;
/*!40000 ALTER TABLE `tr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unidadFormacion`
--

DROP TABLE IF EXISTS `unidadFormacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unidadFormacion` (
  `clave` varchar(10) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  PRIMARY KEY (`clave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unidadFormacion`
--

LOCK TABLES `unidadFormacion` WRITE;
/*!40000 ALTER TABLE `unidadFormacion` DISABLE KEYS */;
INSERT INTO `unidadFormacion` VALUES ('MT1004','Proba'),('MT3006','Análisis'),('TC3001','Estructura de datos'),('TC3002','Bases de datos'),('TC3003','Métodos numéricos'),('TC4003','Redes'),('TC5004','Sistemas Operativos');
/*!40000 ALTER TABLE `unidadFormacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(40) DEFAULT NULL,
  `credit` decimal(20,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'ana',1400.00),(2,'pepe',500.00),(3,'toño',750.00);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `MDP_Autorizados`
--

/*!50001 DROP VIEW IF EXISTS `MDP_Autorizados`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`TC2005B_403_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `MDP_Autorizados` AS select `MDP_proyecto`.`id` AS `id`,`MDP_proyecto`.`nombre` AS `nombre`,`MDP_proyecto`.`video` AS `video`,`MDP_proyecto`.`poster` AS `poster`,`MDP_proyecto`.`id_area` AS `id_area`,`MDP_proyecto`.`id_evaluacion` AS `id_evaluacion`,`MDP_proyecto`.`id_profesor` AS `id_profesor`,`MDP_proyecto`.`id_edicion` AS `id_edicion`,`MDP_proyecto`.`Id_unidad_formacion` AS `id_unidad_formacion` from (`MDP_proyecto` join `MDP_estatus` on((`MDP_proyecto`.`id_estatus` = `MDP_estatus`.`id`))) where (`MDP_estatus`.`nombre` = 'Autorizado') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `MDP_Autorizados_NoAutorizados`
--

/*!50001 DROP VIEW IF EXISTS `MDP_Autorizados_NoAutorizados`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`TC2005B_403_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `MDP_Autorizados_NoAutorizados` AS select `MDP_proyecto`.`id` AS `id`,`MDP_proyecto`.`nombre` AS `nombre`,`MDP_proyecto`.`video` AS `video`,`MDP_proyecto`.`poster` AS `poster`,`MDP_proyecto`.`id_area` AS `id_area`,`MDP_proyecto`.`id_evaluacion` AS `id_evaluacion`,`MDP_proyecto`.`id_profesor` AS `id_profesor`,`MDP_proyecto`.`id_edicion` AS `id_edicion`,`MDP_proyecto`.`Id_unidad_formacion` AS `id_unidad_formacion`,`MDP_estatus`.`nombre` AS `estatus` from (`MDP_proyecto` join `MDP_estatus` on((`MDP_proyecto`.`id_estatus` = `MDP_estatus`.`id`))) where ((`MDP_estatus`.`nombre` = 'Autorizado') or (`MDP_estatus`.`nombre` = 'No autorizado')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `MDP_Orden_calificacion`
--

/*!50001 DROP VIEW IF EXISTS `MDP_Orden_calificacion`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`TC2005B_403_1`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `MDP_Orden_calificacion` AS select `MDP_proyecto`.`id` AS `id`,`MDP_proyecto`.`nombre` AS `nombre`,`MDP_proyecto`.`video` AS `video`,`MDP_proyecto`.`poster` AS `poster`,`MDP_proyecto`.`id_area` AS `id_area`,`MDP_proyecto`.`id_evaluacion` AS `id_evaluacion`,`MDP_proyecto`.`id_profesor` AS `id_profesor`,`MDP_proyecto`.`id_edicion` AS `id_edicion`,`MDP_proyecto`.`Id_unidad_formacion` AS `id_unidad_formacion`,avg(`MDP_jurado_proyecto`.`calificacion`) AS `promedio` from (`MDP_proyecto` join `MDP_jurado_proyecto` on((`MDP_proyecto`.`id` = `MDP_jurado_proyecto`.`id_proyecto`))) group by `MDP_proyecto`.`id` order by avg(`MDP_jurado_proyecto`.`calificacion`) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-04 18:35:35
