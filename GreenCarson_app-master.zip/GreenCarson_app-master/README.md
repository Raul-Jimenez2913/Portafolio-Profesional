# GreenCarson_app
Proyecto final de iOS mostrado en la rama master

Frameworks utilizados (iOS):
* DGCharts.framework: https://github.com/danielgindi/Charts
* Firebase: https://firebase.google.com/docs/ios/setup?hl=es
  * FirebaseAnalytics
  * FirebaseAnalyticsSwift
  * FirebaseAuth
  * FirebaseFirestore
* SnapKit: https://github.com/SnapKit/SnapKit
