/*
Proyecto final Videojuegos - Juego de plataformas

*****LavaJump*****

Christian Ra�l Jim�nez Hern�ndez | A01736302
Luis �ngel Cruz Garc�a | A01736345
Jacqueline Villa Asencio | A01736339
*/

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <stdlib.h>
#include <iostream>
#include <random>
#include <iomanip>
#include "RgbImage.h"
#include <string>
#include <vector>

#define NTextures 3
GLuint	texture[NTextures];
//Cambiar por enlace de la imagen
char* filename0 = "C:/Users/LACG2/OneDrive/Escritorio/plataformas/lavaL.bmp";
char* filename1 = "C:/Users/LACG2/OneDrive/Escritorio/plataformas/piedrasL.bmp";
char* filename2 = "C:/Users/LACG2/OneDrive/Escritorio/plataformas/estrellasL.bmp";

//partida terminada
bool gameOver = false;
bool winner = false;

std::string puntuacion;

//Variables dimensiones de la pantalla
int WIDTH=700;
int HEIGTH=700;
//Variables para establecer los valores de gluPerspective
float FOVY=60.0;
float ZNEAR=0.01;
float ZFAR=900.0;
//Variables para definir la posicion del observador
float EYE_X=100.0; //15 40
float EYE_Y=60.0; //10 10
float EYE_Z=100.0; //15 40
float CENTER_X=0.0;
float CENTER_Y=0.0;
float CENTER_Z= 0.0;
float UP_X=0;
float UP_Y=1;
float UP_Z=0;
//Variables para dibujar los ejes del sistema
float X_MIN=-500;
float X_MAX=500;
float Y_MIN=-500;
float Y_MAX=500;
float Z_MIN=-500;
float Z_MAX=500;

//Size del tablero
int DimBoard = 400;

float Theta=0;
float PI = 3.14159265359;

//Variables necesarias para el algoritmo BFS
 struct Node {
    float x, z;
};

Node playerNode = {0.0f, 0.0f};
Node enemyNode = {25.0f, 0.0f};
std::vector<Node> path;
bool enemyFound = false;
float plataformaActual = 0;

void loadTextureFromFile(char *filename, int index)
{
	glClearColor (0.0, 0.0, 0.0, 0.0);
	glShadeModel(GL_FLAT);
	//glEnable(GL_DEPTH_TEST);

	RgbImage theTexMap( filename );

    //generate an OpenGL texture ID for this texture
    glGenTextures(1, &texture[index]);
    //bind to the new texture ID
    glBindTexture(GL_TEXTURE_2D, texture[index]);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T, GL_CLAMP);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, 3, theTexMap.GetNumCols(), theTexMap.GetNumRows(), 0,
                     GL_RGB, GL_UNSIGNED_BYTE, theTexMap.ImageData());
    theTexMap.Reset();
}

void drawText(const char* text, float x, float y) {
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    glOrtho(0, glutGet(GLUT_WINDOW_WIDTH), 0, glutGet(GLUT_WINDOW_HEIGHT), -1, 1);

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    glRasterPos2f(x, y);

    for (const char* c = text; *c != '\0'; ++c) {
        if (*c == '\n') {
            y -= 18.0;
            glRasterPos2f(x, y);
        } else {
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
        }
    }

    glPopMatrix();

    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
}

void pantallaFinal() {
    // Limpia la pantalla
    gameOver = true;
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Establece el color de dibujo en blanco
    glColor3f(1.0, 1.0, 1.0);
    //18 -> size letra
    float x = glutGet(GLUT_WINDOW_WIDTH) / 2.0 ;
    float y = glutGet(GLUT_WINDOW_HEIGHT) / 2.0 - 18.0 / 2.0;
    std::string mensaje = "GAME OVER\n" + puntuacion;
    drawText(mensaje.c_str(), x, y);
    glutSwapBuffers();
}

void pantallaGanador() {
    // Limpia la pantalla
    winner = true;
    glClearColor(1.0, 1.0, 0.0, 0.0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    // Establece el color de dibujo en negro
    glColor3f(0.0, 0.0, 0.0);
    //18 -> size letra
    float x = glutGet(GLUT_WINDOW_WIDTH) / 2.0 ;
    float y = glutGet(GLUT_WINDOW_HEIGHT) / 2.0 - 18.0 / 2.0;
    std::string mensaje = "Felicidades\nGracias por jugar\n" + puntuacion;
    drawText(mensaje.c_str(), x, y);
    glutSwapBuffers();
}

void init()
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(FOVY, (GLfloat)WIDTH/HEIGTH, ZNEAR, ZFAR);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(EYE_X,EYE_Y,EYE_Z,CENTER_X,CENTER_Y,CENTER_Z,UP_X,UP_Y,UP_Z);
    glClearColor(0,0,0,0);

    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    glShadeModel(GL_FLAT);
    glEnable(GL_DEPTH_TEST);
    loadTextureFromFile(filename0,0);
    loadTextureFromFile(filename1,1);
    loadTextureFromFile(filename2,2);
    srand(time(nullptr));
}

class Plataforma{
public:
    float Position[3];
    int Size;

    Plataforma(float x, float y, float z, int s){
        Position[0] = x;
        Position[1] = y;
        Position[2] = z;
        Size = s;
    }

    void drawPlataforma(){
    glPushMatrix();
    glTranslated(Position[0],Position[1],Position[2]);
    glScalef(0.45, 0.1, 0.45);

    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[1]);

    glBegin(GL_QUADS);
    // enfrente
    glTexCoord2f(0.0f, 0.0f); glVertex3f(-Size, -Size,  Size);
    glTexCoord2f(1.0f, 0.0f); glVertex3f( Size, -Size,  Size);
    glTexCoord2f(1.0f, 1.0f); glVertex3f( Size,  Size,  Size);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(-Size,  Size,  Size);
    // atras
    glTexCoord2f(1.0f, 0.0f); glVertex3f(-Size, -Size, -Size);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(-Size,  Size, -Size);
    glTexCoord2f(0.0f, 1.0f); glVertex3f( Size,  Size, -Size);
    glTexCoord2f(0.0f, 0.0f); glVertex3f( Size, -Size, -Size);
    // izquierda
    glTexCoord2f(0.0f, 1.0f); glVertex3f(-Size,  Size,  Size);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(-Size, -Size,  Size);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(-Size, -Size, -Size);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(-Size,  Size, -Size);
    // derecha
    glTexCoord2f(1.0f, 1.0f); glVertex3f( Size,  Size,  Size);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(-Size,  Size,  Size);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(-Size,  Size, -Size);
    glTexCoord2f(1.0f, 0.0f); glVertex3f( Size,  Size, -Size);
    // inferior
    glTexCoord2f(1.0f, 0.0f); glVertex3f(-Size, -Size,  Size);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(-Size, -Size, -Size);
    glTexCoord2f(0.0f, 1.0f); glVertex3f( Size, -Size, -Size);
    glTexCoord2f(0.0f, 0.0f); glVertex3f( Size, -Size,  Size);
    // superior
    glTexCoord2f(0.0f, 1.0f); glVertex3f(-Size,  Size,  Size);
    glTexCoord2f(1.0f, 1.0f); glVertex3f( Size,  Size,  Size);
    glTexCoord2f(1.0f, 0.0f); glVertex3f( Size,  Size, -Size);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(-Size,  Size, -Size);
    glEnd();

// Dibujar los bordes
    glLineWidth(2.0f); // establecer el ancho de la l�nea en 2 p�xeles
    glColor3f(1.0f, 1.0f, 1.0f); // color blanco
    glBegin(GL_LINE_LOOP);
    // Enfrente
    glVertex3f(-Size, -Size, Size);
    glVertex3f( Size, -Size, Size);
    glVertex3f( Size, Size, Size);
    glVertex3f(-Size, Size, Size);
    glEnd();

    glBegin(GL_LINE_LOOP);
    // Atr�s
    glVertex3f(-Size, -Size, -Size);
    glVertex3f(-Size, Size, -Size);
    glVertex3f( Size, Size, -Size);
    glVertex3f( Size, -Size, -Size);
    glEnd();

    glBegin(GL_LINE_LOOP);
    // Izquierda
    glVertex3f(-Size, Size, Size);
    glVertex3f(-Size, -Size, Size);
    glVertex3f(-Size, -Size, -Size);
    glVertex3f(-Size, Size, -Size);
    glEnd();

    glBegin(GL_LINE_LOOP);
    // Derecha
    glVertex3f( Size, Size, Size);
    glVertex3f(-Size, Size, Size);
    glVertex3f(-Size, Size, -Size);
    glVertex3f( Size, Size, -Size);
    glEnd();

    glBegin(GL_LINE_LOOP);
    // Inferior
    glVertex3f(-Size, -Size, Size);
    glVertex3f(-Size, -Size, -Size);
    glVertex3f( Size, -Size, -Size);
    glVertex3f( Size, -Size, Size);
    glEnd();

    glBegin(GL_LINE_LOOP);
    // Superior
    glVertex3f(-Size, Size, Size);
    glVertex3f( Size, Size, Size);
    glVertex3f( Size, Size, -Size);
    glVertex3f(-Size, Size, -Size);
    glEnd();

    glDisable(GL_TEXTURE_2D); // desactivar el mapeo de texturas
    glPopMatrix();
}

};

const int numeroPlataformas = 25;
Plataforma plataformas[numeroPlataformas] = {
Plataforma(0.0, 3.0, 0.0, 30),//1
    Plataforma(0.0, 8.0, 35.0, 30),//2
    Plataforma(35.0, 13.0, 35.0, 30),//3
    Plataforma(70.0, 23.0, 35.0, 30),//4
    Plataforma(100.0, 33.0, 35.0, 30),//5
    Plataforma(100.0, 43.0, 0.0, 30),//6
    Plataforma(69.0, 53.0, 0.0, 30),//7
    Plataforma(35.0, 63.0, 0.0, 30),//8
    Plataforma(34.0, 73.0, -34.0, 30),//9
    Plataforma(35.0, 81.0, -70.0, 30),//10
    Plataforma(70.0, 90.0, -70.0, 30),//11
    Plataforma(105.0, 98.0, -70.0, 30),//12
    Plataforma(130.0, 105.0, -70.0, 30),//13
    Plataforma(130.0, 115.0, -35.0, 30),//14
    Plataforma(130.0, 125.0, 0.0, 30),//15
    Plataforma(130.0, 135.0, 30.0, 30),//16
    Plataforma(130.0, 145.0, 60.0, 30),//17
    Plataforma(130.0, 155.0, 85.0, 30),//18
    Plataforma(105.0, 165.0, 85.0, 30),//19
    Plataforma(80.0, 175.0, 85.0, 30),//20
    Plataforma(55.0, 185.0, 85.0, 30),//21
    Plataforma(55.0, 195.0, 110.0, 30),//22
    Plataforma(55.0, 205.0, 135.0, 30),//23
    Plataforma(55.0, 215.0, 170.0, 30),//24
    Plataforma(55.0, 225.0, 200.0, 30),//25
};


class Enemigo{
public:
    float Position[3] = {25.0, 8.0, 0.0};
    float radio = 1.0; // radio de la esfera de colision
    void draw(){
        glPushMatrix();
        glTranslatef(Position[0],Position[1],Position[2]);
        glColor3f(0.0,0.0,0.5);
        glutSolidCube(2.0);
        glPopMatrix();
    }
    void update(float x, float y, float z){
        Position[0] = x;
        Position[1] = y;
        Position[2] = z;
    }
};

class Jugador{
public:
    bool u = true; //indicar que esta arriba
    bool j = false; //indicar que se salta
    int p = 0; //indice de la plataforma actual
    float radio = 1.0;
    float Position[3] = {0.0, 6.0, 0.0};
    float Direction[3] = {0.0, 0.0, 0.0};

    void draw(){
        glPushMatrix();
        glTranslatef(Position[0],Position[1],Position[2]);
        glColor3f(1.0,1.0,1.0);
        glutSolidCube(2.0);
        glPopMatrix();
    }

    void updateDirection(int dir){
       if (dir == 1){
            Direction[0] += 2.0;
       }
       else if (dir == 2){
            Direction[0] -= 2.0;
       }
       else if (dir == 3){
            Direction[2] += 2.0;
       }
       else if (dir == 4){
            Direction[2] -= 2.0;
       }
       else if (dir  == 5){
            j = true;
            if (Direction[1] < 20.0 && u == true){
                Position[1]+=1.0;
                Direction[1]+=1.0;
                if (Direction[1] == 20.0){
                    u = false;
                }
            }
            else if (u == false){
                Position[1]-=1.0;
                Direction[1]-=1.0;
                if (Direction[1] == 1.0){
                    u = true;
                    j = false;
                }
                else if (Position[1] < 0.0){
                    Position[1] = 0.0;
                    pantallaFinal();
                }
            }
       }
       else return;
    }

    void update(){
        j = true;

        // Verificar si el jugador est� sobre la plataforma
        for(int i = 0; i < numeroPlataformas; i++){
            //plataforma superior
            if (Position[0] >= plataformas[i].Position[0] - plataformas[i].Size/2 &&
                Position[0] <= plataformas[i].Position[0] + plataformas[i].Size/2 &&
                Position[2] >= plataformas[i].Position[2] - plataformas[i].Size/2 &&
                Position[2] <= plataformas[i].Position[2] + plataformas[i].Size/2 &&
                Position[1] == plataformas[i].Position[1] + plataformas[i].Size/10){
                u = true;
                p = i;
                Direction[1] = 1.0;
                plataformaActual = Position[1] + 1.0;
                break;
            }
            //plataforma inferior
            else if (Position[0] >= plataformas[i].Position[0] - plataformas[i].Size/2 &&
                Position[0] <= plataformas[i].Position[0] + plataformas[i].Size/2 &&
                Position[2] >= plataformas[i].Position[2] - plataformas[i].Size/2 &&
                Position[2] <= plataformas[i].Position[2] + plataformas[i].Size/2 &&
                Position[1] > plataformas[i].Position[1] + plataformas[i].Size/10 + 20){
                Direction[1] = 10.0;
                u = false;
                p = i;
                Direction[1] = 1.0;
                plataformaActual = Position[1] + 1.0;
                break;
            }
        }
        if (Position[0] < plataformas[p].Position[0] - plataformas[p].Size/2 ||
            Position[0] > plataformas[p].Position[0] + plataformas[p].Size/2 ||
            Position[2] < plataformas[p].Position[2] - plataformas[p].Size/2 ||
            Position[2] > plataformas[p].Position[2] + plataformas[p].Size/2){
                u =  false;
                Direction[1] = 0.0;
        }
        Position[0] += Direction[0];
        Position[2] += Direction[2];

        Direction[0] = 0.0;
        Direction[2] = 0.0;

        //cambio del observador respecto a Y
        switch(p){
        case(6):
        case(7):
        case(8):
        case(9):
            CENTER_Y = 100.0;
            EYE_Y = 100.0;
            break;
        case(10):
        case(11):
            CENTER_Y = 130.0;
            EYE_Y = 180.0;
            break;
        case(12):
        case(13):
        case(14):
        case(15):
        case(16):
            CENTER_Y = 150.0;
            EYE_Y = 150.0;
        break;
        case(17):
        case(18):
        case(19):
        case(20):
        case(21):
            CENTER_Y = 200.0;
            EYE_Y = 200.0;
        case(22):
        case(23):
        case(24):
        case(25):
            CENTER_Y = 230.0;
            EYE_Y = 230.0;
        break;
        default:
            CENTER_Y = 0.0;
            EYE_Y = 60.0;
        }
    }

    bool buscaColision(Enemigo& e) {
        float dx = Position[0] - e.Position[0];
        float dy = Position[1] - e.Position[1];
        float dz = Position[2] - e.Position[2];
        float distancia = sqrt(dx*dx + dy*dy + dz*dz);
        return distancia < radio + e.radio;
    }

};

//Se crean los objetos
Jugador jugador;
Enemigo enemigo;

 void update()
 {
    if (jugador.j == true)    jugador.updateDirection(5);
    jugador.update();
    playerNode.x = jugador.Position[0];
    playerNode.z = jugador.Position[2];
    if (!enemyFound) {
        // Implementar el algoritmo BFS para encontrar el camino hacia el jugador
        // El resultado se almacena en el vector path
        path.push_back(enemyNode);
        path.push_back(playerNode);
        enemyFound = true;
    }
    // Calcular la direcci�n en la que el enemigo debe moverse para seguir al jugador
    float dx = playerNode.x - enemyNode.x;
    float dz = playerNode.z - enemyNode.z;
    float distance = std::sqrt(dx * dx + dz * dz);
    if (distance > 0.01f) {
        dx /= distance;
        dz /= distance;
        enemyNode.x += dx * 0.3f;
        enemyNode.z += dz * 0.3f;
    }
    enemigo.update(enemyNode.x,plataformaActual,enemyNode.z);

 }

void display()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[2]); // Asignar la textura a la esfera

    glPushMatrix();
    glColor3f(0.7, 0.19, 0.34);
    glTranslatef(500.0f, 0.0f, 500.0f); // mover la esfera

    int slices = 20; //Secciones horizontales
    int stacks = 20; //Secciones verticales
    float radio = 1000.0f;

    for (int i = 0; i < slices; ++i) {
        glBegin(GL_TRIANGLE_STRIP);
        for (int j = 0; j <= stacks; ++j) {
            float theta = i * 2.0f * PI / slices;
            float phi = j * PI / stacks;
            float x = radio * sin(phi) * cos(theta);
            float y = radio * cos(phi);
            float z = radio * sin(phi) * sin(theta);
            float u = (float)i / slices;
            float v = (float)j / stacks;
            glTexCoord2f(u, v);
            glVertex3f(x, y, z);

            theta = (i + 1) * 2.0f * PI / slices;
            x = radio * sin(phi) * cos(theta);
            y = radio * cos(phi);
            z = radio * sin(phi) * sin(theta);

            u = (float)(i + 1) / slices;
            v = (float)j / stacks;

            glTexCoord2f(u, v);
            glVertex3f(x, y, z);
        }
        glEnd();
    }

    glPopMatrix();

    glDisable(GL_TEXTURE_2D);

    glColor3f(1.0, 0.5, 0.0);
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[0]); // Asignar la textura al piso
    glBegin(GL_QUADS);
        glTexCoord2f(0.0, 0.0); glVertex3d(-DimBoard, 0.0, -DimBoard);
        glTexCoord2f(1.0, 0.0); glVertex3d(DimBoard, 0.0, -DimBoard);
        glTexCoord2f(1.0, 1.0); glVertex3d(DimBoard, 0.0, DimBoard);
        glTexCoord2f(0.0, 1.0); glVertex3d(-DimBoard, 0.0, DimBoard);
    glEnd();
    glDisable(GL_TEXTURE_2D);
    //Actualizar variables
    update();

    //Ver si el jugador termino la partida
    if (jugador.buscaColision(enemigo)) pantallaFinal();
    if (jugador.p == numeroPlataformas - 1) pantallaGanador();

    //Dibujar personajes
    jugador.draw();
    enemigo.draw();

    for(int i = 0; i < numeroPlataformas; i++){
        plataformas[i].drawPlataforma();
    }
    Sleep(50);

    //Mostrar puntaje en pantalla
    puntuacion = "Puntaje: " + std::to_string(jugador.p);
    drawText(puntuacion.c_str(), 10.0, glutGet(GLUT_WINDOW_HEIGHT) - 25.0);

    glutSwapBuffers();
}


void idle()
{
     if (gameOver) pantallaFinal();
     else if (winner) pantallaGanador();
     else display();
}

//ifs que logren captar si hay dos teclas presionadas al mismo tiempo
void keyboard(unsigned char key, int x, int y)
{
    if (gameOver) {
        return;
    }
    if (key == 'd'){
        jugador.updateDirection(1);
            EYE_X += jugador.Direction[0];
            EYE_Z += jugador.Direction[2];
            CENTER_X = jugador.Position[0];
            CENTER_Z = jugador.Position[2];
    }
    if (key == 'a'){
        jugador.updateDirection(2);
            EYE_X += jugador.Direction[0];
            EYE_Z += jugador.Direction[2];
            CENTER_X = jugador.Position[0];
            CENTER_Z = jugador.Position[2];
    }
    if (key == 's'){
        jugador.updateDirection(3);
            EYE_X += jugador.Direction[0];
            EYE_Z += jugador.Direction[2];
            CENTER_X = jugador.Position[0];
            CENTER_Z = jugador.Position[2];
    }
    if (key == 'w'){
        jugador.updateDirection(4);
            EYE_X += jugador.Direction[0];
            EYE_Z += jugador.Direction[2];
            CENTER_X = jugador.Position[0];
            CENTER_Z = jugador.Position[2];
    }
    glLoadIdentity();
    gluLookAt(EYE_X,EYE_Y,EYE_Z,CENTER_X,CENTER_Y,CENTER_Z,UP_X,UP_Y,UP_Z);
    //Reactualizar el sistema grafico de acuerdo al observador
    //forzar a opengl
    glutPostRedisplay();
}


int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH );
    glutInitWindowPosition(0, 0);
    glutInitWindowSize(WIDTH, HEIGTH);
    glutCreateWindow("Juego de plataformas");
    init();
    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutKeyboardFunc(keyboard);
    glutMainLoop();
    return 0;
}
