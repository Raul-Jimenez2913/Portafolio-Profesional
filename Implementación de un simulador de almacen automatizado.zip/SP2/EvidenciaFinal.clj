;CREATED BY: CHRISTIAN RAÚL JIMÉNEZ HERNÁNDEZ - A01736302
;*******Importacion de Recursos requeridos de java**********
(require '[clojure.java.io :as io]
         '[clojure.string :as string])

;***********Leer el archivo de entrada***************
(defn entrada [ninventario]
  (load-file (str "entradas" ninventario ".txt")))

(defn leer-archivo [ruta]
  (with-open [archivo (io/reader ruta)]
    (read-string (slurp archivo))))

;*****Leer archivo donde se encuentra el almacén*****
(defn arch [ninventario] (leer-archivo (str "almacen"  ninventario  ".txt"))) ;; abre el archivo creado

;**********Total de columnas en la matriz************
(defn columnas [alm]
  (if (empty? alm)
    0
    (if (empty? (first alm))
      0
      (+ 1 (columnas (map rest alm))))))

;*************Total de filas en la matriz************
(defn filas [alm]
  (if (empty? alm)
    0
    (+ 1 (filas (rest alm)))))

;;************Reescribir estado actual****************
(defn Estado-Actual [estado ninventario]
  (with-open [output-port (clojure.java.io/writer (str "actual" ninventario ".txt") :append false)]
    (.write output-port (str estado))))

;**********Abrir archivo y regresar el valor de la línea********
(defn leer [nombre]
  (with-open [act (clojure.java.io/reader nombre)]
    (let [x (read-string (slurp act))]
      x)))

;************Buscar un elemento en la matriz de acuerdo a la fila y columna correspondiente***********
(defn buscar-elemento [matriz fila col]
  (get-in matriz [fila col]))

;*****************Encontrar fila y columna de un elemento en la matriz*********************
(defn buscar [matrix valor]
  (letfn [(buscar-fila [fila cola]
            (cond (empty? fila) false
                  (= (first (first fila)) valor) [cola 0]
                  :else (buscar-fila (rest fila) (inc cola))))
          (buscar-matriz [filas col]
            (cond (empty? filas) false
                  (buscar-fila (first filas) 0) [(first (buscar-fila (first filas) 0)) col]
                  :else (buscar-matriz (rest filas) (inc col))))]
    (buscar-matriz matrix 0)))

;***************Función para MODIFICAR INVENTARIO***********************
(defn cambiar-elemento [vector indice nuevo-valor]
  (assoc vector indice nuevo-valor))

(defn modificar-elemento-matriz [matriz fila columna nuevo-valor]
  (assoc-in matriz [fila columna] nuevo-valor))

(defn modificar [almacen fila columna nuevo-valor ninventario]
  (let [matriz-modificada (modificar-elemento-matriz (arch ninventario) fila columna nuevo-valor)]
    (with-open [almacen (io/writer (str "almacen" ninventario ".txt"))]
      (spit almacen matriz-modificada))))

;***************Funciones para obtener el camino a la casilla indicada*****************+
(defn opciones-cadr [destino actual ninventario]
  (cond (= (second destino) (second actual)) '()
        (and (= (second destino) (dec (filas (arch ninventario)))) (= (second actual) 0)) (cons 'arr (opciones-cadr destino (list (first actual) (dec (filas (arch ninventario))))ninventario))
        (and (= (second destino) 0) (= (second actual) (dec (filas (arch ninventario))))) (cons 'aba (opciones-cadr destino (list [(first actual) 0])ninventario))
        (< (second destino) (second actual)) (cons 'arr (opciones-cadr destino (list (first actual) (dec (second actual)))ninventario))
        (> (second destino) (second actual)) (cons 'aba (opciones-cadr destino (list (first actual) (inc (second actual)))ninventario))
        :else "error"))

(defn opciones-car [destino actual]
  (cond (= (first destino) (first actual)) '()
        (< (first destino) (first actual)) (cons 'i (opciones-car destino (list (- (first actual) 1) (second actual))))
        :else (cons 'd (opciones-car destino (list (+ 1 (first actual)) (second actual))))))

;*****************Función RETIRAR PRODUCTO***********
(defn resta [a b]
  (- a b))

(defn retirar-aux [producto cantidad almacen precio fila columna alm ninventario]
  (cond
    (= almacen 0) (do
                    (println "ERROR: No hay producto en el almacén")
                    alm)
    (> cantidad almacen) (do
                           (println "Cantidad insuficiente para retirar")
                           alm)
    :else (do
            (modificar alm fila columna [producto (resta almacen cantidad) precio] ninventario)
            (println "Cantidad restante en almacen del producto: " producto " es de: " (resta almacen cantidad)))))

(defn retirar [producto cantidad n]
  (let [ubicacion-producto (buscar (arch n) producto)]
    (if (not= ubicacion-producto false)
      (let [fila (second ubicacion-producto)
            columna (first ubicacion-producto)
            info-producto (buscar-elemento (arch n) fila columna)]
        (retirar-aux (first info-producto)
                     cantidad
                     (second info-producto)
                     (nth info-producto 2)
                     fila
                     columna
                     (arch n) n)(Estado-Actual [fila columna] n))
      (println "El producto no se encuentra en el almacén"))))

;**************Función AGREGAR PRODUCTO AL ALMACEN****************
(defn suma [a b]
  (+ a b))

(defn agregar-aux [producto cantidad almacen precio fila columna alm n]
  (println "Cantidad agregada: " cantidad)
  (println "Cantidad total del almacen: " producto " es de:" (suma almacen cantidad))
  (modificar alm fila columna [producto (suma almacen cantidad) precio] n))

(defn agregar [producto cantidad n]
  (let [ubicacion-producto (buscar (arch n) producto)]
    (if (not= ubicacion-producto false)
      (let [fila (second ubicacion-producto)
            columna (first ubicacion-producto)
            info-producto (buscar-elemento (arch n) fila columna)]
        (agregar-aux (first info-producto)
                     cantidad
                     (second info-producto)
                     (nth info-producto 2)
                     fila
                     columna
                     (arch n) n)(Estado-Actual [fila columna] n))
      (println "El producto no se encuentra en el almacén"))))


;***********Algoritmo del autómata determinístico que detecta el lenguaje de 4 movimientos******
;                     arr = arriba, aba = abajo, izq = izquierda, der = derecha
(defn mover-aux [estado-act entrada alm n]
  (cond (empty? entrada) (do (Estado-Actual estado-act n) estado-act)
        (= (first entrada) 'izq)
        (if (= (first estado-act) 0)
          "Movimiento no permitido"
          (do (Estado-Actual [(dec (first estado-act)) (second estado-act)] n) (mover-aux [(dec (first estado-act)) (second estado-act)] (rest entrada) alm n)))
        (= (first entrada) 'der)
        (if (= (first estado-act) (dec (columnas alm)))
          "Movimiento no permitido"
          (do (Estado-Actual [(inc (first estado-act)) (second estado-act)] n) (mover-aux [(inc (first estado-act)) (second estado-act)] (rest entrada) alm n)))
        (= (first entrada) 'arr)
        (if (= (second estado-act) 0)
          (do (Estado-Actual [(first estado-act) (dec (filas alm))] n) (mover-aux [(first estado-act) (dec (filas alm))] (rest entrada) alm n))
          (do (Estado-Actual [(first estado-act) (dec (second estado-act))] n) (mover-aux [(first estado-act) (dec (second estado-act))] (rest entrada) alm n)))
        (= (first entrada) 'aba)
        (if (= (second estado-act) (dec (filas alm)))
          (do (Estado-Actual [(first estado-act) 0] n) (mover-aux [(first estado-act) 0] (rest entrada) alm n))
          (do (Estado-Actual [(first estado-act) (inc (second estado-act))] n) (mover-aux [(first estado-act) (inc (second estado-act))] (rest entrada) alm n)))
        :else "Movimiento no permitido"))

;**************funcion MOVER CARRUSEL DEL ALMACEN PARA LA VENTANILLA*****************
(defn mover [entrada alm ninventario]
  (if (= (mover-aux (leer (str "actual" ninventario ".txt")) entrada alm ninventario) "Movimiento no permitido")
    (println "ERROR en la entrada, movimiento no permitido en la función 'mover' (inventario: " ninventario ")")
    (do
      (println "Producto en ventanilla: " (buscar-elemento alm (second (leer (str "actual" ninventario ".txt"))) (first (leer (str "actual" ninventario ".txt")))))
      (leer (str "actual" ninventario ".txt")))))

;;***************Función Valor total del inventario en el carrusel*******
(defn valor-inventario [n]
  (if (empty? (arch n))
    0
      (println "El valor total del inventario es: (inventario: " n ")"
      (apply + (map (fn [p] (* (second p) (nth p 2))) (apply concat (arch n)))))))

(defn total-inventario [numero]
  (apply + (map (fn [fila] (* (second fila) (first (rest (rest fila))))) (apply concat (arch numero)))))

;****************Función para encontrar los productos con menor inventario*************
(defn menores [stock]
  (< (second stock) 5))

(defn poco-stock [n]
  (if (empty? (arch n))
    (println "No existen productos disponibles")
      (println "Los productos con poco inventario son: (inventario: " n ")"
      (filter menores (apply concat (arch n))))))

;*********lista del top 10% de carruseles con mayor valor de inventario, mostrando el identificador del carrusel y su valor*********
;Calcular los inventarios con mayor valor de inventario
(defn calcular-mayores [lista]
  (let [n (count lista)
        ult (max 1 (quot (* n 10) 100))]
    (take-last ult (sort-by :value lista))))

;***** Funcion principal de cada inventario, la cual es paralelizable******
(defn Resultados-inventario [n]
(Estado-Actual [0 0] n)
(entrada n)
(poco-stock n)
(println "Transacciones del carrusel " n " completadas")
(valor-inventario n)
)

;*********Funcion main que interacciona con el usuario y ejecuta el paralelismo******
(defn main []
  (println "¿Desea iniciar transacciones? (s/n)")
  (let [input (read-line)]
    (if (= (clojure.string/lower-case input) "s")
      (do
        (time (doall (pmap #(Resultados-inventario %) (range 1 51))))
        (println "10% de los almacenes con mayor inventario: ")
        (time (let [totals (map-indexed (fn [index value] {:Carrusel (inc index) :value value}) (map #(total-inventario %) (range 1 51)))]
          (println (calcular-mayores totals)))))
      (println "No se iniciarán transacciones"))))
(main)