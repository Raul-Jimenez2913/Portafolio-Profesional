import random
import os

productos = [
    "Alprazolam", "Beclometasona", "Lovastatina", "Terbutalina", "Fluorouracilo", 
    "Clonazepam", "Biperideno", "Magnesio", "Timolol", "Haloperidol",
    "Clozapina", "Bisacodilo", "Mebendazol", "Tinidazol", "Heparina", 
    "Diazepam", "Calcitriol", "Metimazol", "Tramadol", "Hidrocortisona", 
    "Fenobarbital", "Captopril", "Metformina", "Trazodona", "Hioscina-NBB",
    "Fentanilo", "Cefalexina", "Mesalazina", "Trimetoprim", "Imipramina",
    "Ketamina", "Ceftriaxona", "Metoprolol", "Verapamilo", "Loratadina",
    "Lorazepam", "Ciprofloxacina", "Nistatina", "Sulfametoxa", "Loperamida",
    "Meperidina", "Clorfeniramina", "Naproxeno", "Evastel", "Litio",
    "Metilfenidato", "Colchicina", "Oxacilina", "Vitamina B1", "Lidocaina",
    "Oxitocina", "Dextrosa", "Omeprazol", "Vitamina C", "Pirantel",
    "Insulina", "Diclofenac", "Pipotiazina", "Vitamina A", "Cloruro",
    "Acetaminofen", "Enalapri", "Prazocina", "Vitamina K", "Hartman",
    "Acetazolamida", "Eritromicina", "Potasio", "Warfarina", "Prednisolona",
    "Aciclovir", "Fenitoina", "Penicilina", "Abacavir", "Cefalexina",
    "Acido Folico", "Fluoxetina", "Propranolol", "Acarbosa", "Captopril",
    "Albendazol", "Gemfibrozilo", "Podofilina", "Alcanfor", "Benzonatato",
    "Amikacina", "Ibuprofeno", "Sucralfato", "Toxoide", "Clavulanato",
    "Amoxicilina", "Ketotifeno", "Sodio", "Fluconazol", "Ambroxol",
    "Azitromicina", "Losartan", "Salbutamol", "Flunarizina", "Sulfacetamida"
]

def generar_matriz(num_matrices, num_productos):
    matrices = []
    for _ in range(num_matrices):
        matriz = []
        productos_seleccionados = productos.copy()  # Hacemos una copia de la lista de productos
        random.shuffle(productos_seleccionados)  # Mezclamos la lista
        productos_seleccionados = productos_seleccionados[:num_productos]  # Tomamos los primeros num_productos de la lista
        for producto in productos_seleccionados:
            cantidad = random.randint(0, 100)
            precio = round(random.uniform(0.5, 100.5), 1)
            matriz.append([producto, cantidad, precio])
        matrices.append(matriz)
    return matrices

def find_next_filename():
    i = 1
    while os.path.exists("almacen%s.txt" % i):
        i += 1
    return "almacen%s.txt" % i

matrices = generar_matriz(20, 5)

filename = find_next_filename()
with open(filename, 'w') as f:
    f.write('[')  # Escribe el corchete de apertura
    for matriz in matrices:
        matriz_str = []
        for producto in matriz:
            producto_str = [f'"{producto[0]}"', producto[1], producto[2]]
            matriz_str.append(f"[{' '.join(map(str, producto_str))}]")
        f.write(f"[{' '.join(matriz_str)}]\n")
    f.write(']')  # Escribe el corchete de cierre
