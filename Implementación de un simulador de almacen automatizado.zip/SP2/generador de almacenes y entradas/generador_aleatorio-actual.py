import os

def find_next_filename():
    i = 1
    while os.path.exists("actual%s.txt" % i):
        i += 1
    return "actual%s.txt" % i

filename = find_next_filename()
with open(filename, 'w') as f:
    f.write('[0 0]')