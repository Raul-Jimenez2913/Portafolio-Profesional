import random
import os

productos = [
    "Alprazolam", "Beclometasona", "Lovastatina", "Terbutalina", "Fluorouracilo", 
    "Clonazepam", "Biperideno", "Magnesio", "Timolol", "Haloperidol",
    "Clozapina", "Bisacodilo", "Mebendazol", "Tinidazol", "Heparina", 
    "Diazepam", "Calcitriol", "Metimazol", "Tramadol", "Hidrocortisona", 
    "Fenobarbital", "Captopril", "Metformina", "Trazodona", "Hioscina-NBB",
    "Fentanilo", "Cefalexina", "Mesalazina", "Trimetoprim", "Imipramina",
    "Ketamina", "Ceftriaxona", "Metoprolol", "Verapamilo", "Loratadina",
    "Lorazepam", "Ciprofloxacina", "Nistatina", "Sulfametoxa", "Loperamida",
    "Meperidina", "Clorfeniramina", "Naproxeno", "Evastel", "Litio",
    "Metilfenidato", "Colchicina", "Oxacilina", "Vitamina B1", "Lidocaina",
    "Oxitocina", "Dextrosa", "Omeprazol", "Vitamina C", "Pirantel",
    "Insulina", "Diclofenac", "Pipotiazina", "Vitamina A", "Cloruro",
    "Acetaminofen", "Enalapri", "Prazocina", "Vitamina K", "Hartman",
    "Acetazolamida", "Eritromicina", "Potasio", "Warfarina", "Prednisolona",
    "Aciclovir", "Fenitoina", "Penicilina", "Abacavir", "Cefalexina",
    "Acido Folico", "Fluoxetina", "Propranolol", "Acarbosa", "Captopril",
    "Albendazol", "Gemfibrozilo", "Podofilina", "Alcanfor", "Benzonatato",
    "Amikacina", "Ibuprofeno", "Sucralfato", "Toxoide", "Clavulanato",
    "Amoxicilina", "Ketotifeno", "Sodio", "Fluconazol", "Ambroxol",
    "Azitromicina", "Losartan", "Salbutamol", "Flunarizina", "Sulfacetamida"
]

def generar_comandos(num_comandos):
    comandos = []
    productos_seleccionados = random.sample(productos, num_comandos)
    for i, producto in enumerate(productos_seleccionados, 1):  # comienza el conteo en 1
        cantidad = random.randint(1, 10)
        accion = random.choice(["agregar", "retirar"])
        comandos.append(f'({accion} "{producto}" {cantidad} {i})')  # añade el índice i
    return comandos

def generar_comandos(num_comandos, archivo_num):
    comandos = []
    productos_seleccionados = random.sample(productos, num_comandos)
    for producto in productos_seleccionados:
        cantidad = random.randint(1, 10)
        accion = random.choice(["agregar", "retirar"])
        comandos.append(f'({accion} "{producto}" {cantidad} {archivo_num})')  # añade el número del archivo
    return comandos

def find_next_filename():
    i = 1
    while os.path.exists("entradas%s.txt" % i):
        i += 1
    return "entradas%s.txt" % i, i  # retorna el nombre del archivo y el número del archivo

filename, archivo_num = find_next_filename()

comandos = generar_comandos(10, archivo_num)

with open(filename, 'w') as f:
    for comando in comandos:
        f.write(comando + '\n')